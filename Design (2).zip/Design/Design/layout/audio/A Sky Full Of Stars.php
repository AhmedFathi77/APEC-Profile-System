<audio loop autoplay hidden>
  <source src="audio/A Sky Full Of Stars.mp3" type="audio/mp3">
  	Your browser does not support the audio tag.
</audio>