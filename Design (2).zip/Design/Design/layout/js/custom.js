$(function(){
    'use strict';
    $('.personal-info .container').mouseenter(function(){
        $('.person-edit').css("display", "inline-block");
        $('.person-add').css("display", "inline-block");
    });
    $('.personal-info .container').mouseleave(function(){
        $('.person-edit').css("display", "none");
        $('.person-add').css("display", "none");
    });
    
    $('.cert .container').mouseenter(function(){
        $('.cert-edit').css("display", "inline-block");
        $('.cert-add').css("display", "inline-block");
    });
    $('.cert .container').mouseleave(function(){
        $('.cert-edit').css("display", "none");
        $('.cert-add').css("display", "none");
    });
    
    $('.train .container').mouseenter(function(){
        $('.train-edit').css("display", "inline-block");
        $('.train-add').css("display", "inline-block");
    });
    $('.train .container').mouseleave(function(){
        $('.train-edit').css("display", "none");
        $('.train-add').css("display", "none");
    });
    
    $('.volunt .container').mouseenter(function(){
        $('.volunt-edit').css("display", "inline-block");
        $('.volunt-add').css("display", "inline-block");
    });
    $('.volunt .container').mouseleave(function(){
        $('.volunt-edit').css("display", "none");
        $('.volunt-add').css("display", "none");
    });
    
});