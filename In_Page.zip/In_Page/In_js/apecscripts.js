    
    function intervew(str) {
      if (str == "-") {
        document.getElementById("interview").innerHTML = '<br><h5 class="text-muted "><span><i class="fa fa-refresh fa-spin"></i></span> Loading avaliablie Slots </h5>';
        return;
      } else {
        if (window.XMLHttpRequest) {
          // code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp = new XMLHttpRequest();
        } else {
          // code for IE6, IE5
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("interview").innerHTML = xmlhttp.responseText;
          }
        }
        xmlhttp.open("GET", "interview.php?q=" + str, true);
        xmlhttp.send();
      }
    }

    function apecscripts(form) {
      
     { //scannig for preference
        var xmlhttp;
        if (window.XMLHttpRequest) {
          xmlhttp = new XMLHttpRequest();
        } else {
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("preftag").innerHTML = xmlhttp.responseText;
          }
        }
        xmlhttp.open("GET", "scan.php", true);
        xmlhttp.send();
      } //end of scanning


      var programtype;
      var eng = 0; //variable to check for faculty
      var elec = document.getElementById('maj_elec');
      var mech = document.getElementById('maj_mech');
      var civil = document.getElementById('maj_civil');
      var arch = document.getElementById('maj_arc');
      var departT = document.getElementById('departT');
      var MajT = document.getElementById('MajT');
      var label = document.getElementById('labeltext');
      var program = document.getElementById('program');
      var credit = document.getElementById('cred_dep');
      var dep = document.getElementById('Depart');
      var idea =document.getElementById('idea');
/*	
  if (form.attend[1].selected) {
        
        idea.style.display = "inline-table";
      } else {
        idea.style.display = "none";
        
      }

*/


/********************************************************************/
/********************block of other *********************************/
      $("#university").change(function() {
        var val1 = $('#university option:selected').val();
        if (val1 == "Other") {
          $(".otheroption").css("display", "block");
        } else {
          $(".otheroption").css("display", "none");
        }
      });

      $("#faculty").change(function() {
        var val1 = $('#faculty option:selected').val();
        if (val1 == "Other") {
          $(".otheroption2").css("display", "block");
        } else {
          $(".otheroption2").css("display", "none");
        }
      });

      $(document).ready(function() {
        var val1 = $('#university option:selected').val();
        var val2 = $('#faculty option:selected').val();
        if (val1 == "Other") {
          $(".otheroption").css("display", "block");
          $("#other").css("display", "block");
        } else {
          $(".otheroption").css("display", "none");
        }
        if (val2 == "Other") {
          $(".otheroption2").css("display", "block");
          $("#other2").css("display", "block");
        } else {
          $(".otheroption2").css("display", "none");
        }

      });
/********************************************************************/
/******************** END block of other ****************************/
      /* bool engineering */
      if (form.faculty[0].selected) {
        eng = 1;
        program.style.display = "inline-table";
      } else {
        departT.style.display = "none";
        MajT.style.display = "none";
        program.style.display = "none";
        eng = 0;
      }
      /* bool engineering */

      if (form.program[1].selected && eng == 1) {
        departT.style.display = "inline-table";
        credit.style.display = 'inline-table';
        dep.style.display = 'none';
        programtype = 2;

      } else {

        dep.style.display = 'inline-table';
        credit.style.display = 'none';
        programtype = 0;
      }

/*******************************/
      if ((form.Year[0].selected || form.Year[1].selected) && programtype == 0) {
        dep.style.display = "none";
        departT.style.display = "none";
        credit.style.display = "none";

      } else if ((form.Year[0].selected)) {

        credit.style.display = "none";
        departT.style.display = "none";
        dep.style.display = 'none';
      } else if (!(form.Year[0].selected) && (programtype == 2) && eng == 1) {

        credit.style.display = "inline-table";
        departT.style.display = "inline-table";
        dep.style.display = 'none';
      } else if (programtype == 0 && eng) {
        label.innerHTML = 'Department:';
        dep.style.display = 'inline-table';
        departT.style.display = "inline-table";
        credit.style.display = 'none';
      }

      if (form.Depart[1].selected && (form.Year[4].selected || form.Year[5].selected) && form.program[0].selected && eng == 1) {
        arch.style.display = 'none';
        civil.style.display = 'none';
        mech.style.display = 'none';
        elec.style.display = 'inline-table';
        MajT.style.display = "inline-table";

      } else if (form.Depart[2].selected && (form.Year[5].selected) && form.program[0].selected && eng == 1) {
        elec.style.display = 'none';
        arch.style.display = 'none';
        civil.style.display = 'inline-table';
        mech.style.display = 'none';
        MajT.style.display = "inline-table";


      } else if (form.Depart[3].selected && (form.Year[4].selected || form.Year[5].selected) && form.program[0].selected && eng == 1) {
        elec.style.display = 'none';
        arch.style.display = 'inline-table';
        MajT.style.display = "inline-table";
        civil.style.display = 'none';
        mech.style.display = 'none';

      } else if (form.Depart[4].selected && (form.Year[4].selected || form.Year[5].selected) && form.program[0].selected && eng == 1) {
        elec.style.display = 'none';
        arch.style.display = 'none';
        civil.style.display = 'none';
        mech.style.display = 'inline-table';
        MajT.style.display = "inline-table";

      } else {
        MajT.style.display = "none";
        elec.style.display = 'none';
        arch.style.display = 'none';
        civil.style.display = 'none';
        mech.style.display = 'none';
      }



    }
$(function() {
      //initially hide the textbox
      var other = document.getElementById('other');
      $("#other").hide();
      $('#university').change(function() {
        if ($(this).find('option:selected').val() == "Other") {
          $("#other").show();
          other.style.display = 'inline-block';

        } else {
          $("#other").hide();
          other.style.display = 'none';
        }
      });

      $("#other").keyup(function(ev) {
        var othersOption = $('#university').find('option:selected');
        if (othersOption.val() == "Other") {
          ev.preventDefault();
          //change the selected drop down text
          $(othersOption).html($("#other").val());
        }
      });

      $("#other2").keyup(function(ev) {
        var othersOption = $('#faculty').find('option:selected');
        if (othersOption.val() == "Other") {
          ev.preventDefault();
          //change the selected drop down text
          $(othersOption).html($("#other2").val());
        }
      });
    });