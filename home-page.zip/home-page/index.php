<?php
$profiles_dir = 'apec-profile';
require '../'.$profiles_dir.'/private/includes/config.php';
if(!isset($_SESSION)){session_start();}
if(!isset($_SESSION['user_id'])){header("location:../".$profiles_dir."/public/login.php");exit();}
$id = $_SESSION['user_id'];
$duration = 30;
require_once'includes/functions.php';
?>
<!DOCTYPE html>     
 <title>Home</title>
 <link rel="stylesheet"  href="css/bootstrap.css">
 <link rel="stylesheet" type="text/css" href="css/normalize.css">
 
  <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->


 <link href="https://fonts.googleapis.com/css?family=Roboto|Titillium+Web" rel="stylesheet"> 
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
    <link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
    <link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
    <script src="js/modernizr.js"></script> <!-- Modernizr -->
    

 <link rel="stylesheet"  href="css/flipclock.css" media="screen">
 <link rel="stylesheet"  href="css/main.css" media="screen">
<script src="js/jquery-1.12.3.min.txt"></script>
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script> 
<script src="js/flipclock.min.js"></script>  






		
</head>

<body>
<section class="header">
   <a href="http://apec-eg.com/apec-profile/public/profile.php" class="web_back">BACK TO PROFILE</a>
</section>



    <section class="box_1">
    
        <section class="now-box">
            <div class="now-box-info">
                    <div class="now-box-div">
                        <span class="upcomming-box-div-span">
                            Now
                        </span>
                    </div>
                    <span class="now-box-span" > APEC'17 Routes</span> 
                    <p class="now-box-p" style="padding-bottom: 5%; ">
                        Do you realize that if you fall into a black hole, You'll see the entire future of the universe un fold in front of you in a matter of moments, and you will emerge into another space-time created by the singularity of the black hole you just fell into?
<br>
For six years, APEC introduced development programs through courses in both technical & nontechnical fields; edging far distances through APEC Routes.
<br>
The Event will be composed of two tracks;
<br>
First: "THE TECHNICAL ROUTES", Which will be a set of sessions providing you with deep knowledge of your field.
<br>
Second: "THE BUSINESS ROUTES", Which will improve your soft skills and broaden your mind to various organizational careers.
<br>
APEC'17 Routes aims to help you LEARN THE LANGUAGE OF CHANGE.
Develop a passion for learning, The future is ours to shape.
<br>
#Learn_The_Language_Of_Change
<br>
                    </p>    
            </div>
            
          <div class="now-box-img">
              <img src="http://apec-eg.com/home-page/imgs/routes-logo.png" alt="" style="max-width: 100%; height: auto; margin-top: 20%" class="circle responsive-img">
          </div>
          
          <div class="now-box-stages">
            <nav >
                <ol class="cd-breadcrumb triangle" style="width:125% ; margin-top:8%">
                    <li id="phase0"><em  style="width:100% ">Join Now</em></li>
                    <li id="phase1"><em style="width:100% ">PST</em></li>
                    <li id="phase2"><em style="width:100% ">Interview</em></li>
                    <li id="phase3"><em style="width:100% ">Result</em></li>
                </ol>
            </nav>
          </div>
    
        </section>



        <section class="upcomming-box">
        <div class="upcomming-box-div">
            <span class="upcomming-box-div-span">
                Upcomming
            </span>
        </div>
        <div class="upcomming-box-img">
              <img src="http://apec-eg.com/home-page/imgs/magazine-logo.png" alt="" style="max-width: 100%; height: auto; margin-top: 15%" class="circle responsive-img">
  
        </div>
        
        <div class="upcomming-box-modal">
              <a class="waves-effect waves-light btn" href="http://apec-eg.com/#magazines">More Detailes</a>

              <!-- Modal Structure -->
              <div id="modal1" class="modal">
                
              </div>
         </div>

        </section>

</section>
<section style="margin-top:3.5%;"> <!-- contains dynamic sections -->
    <section class="box_2" id="s-phase0" style="display: none;">

         
                  

        
        <section class="icons-bar">

                        <div class="icon" id="all" ><img src="imgs/filter-filled-50.png" ></div>
                        <div class="icon " id="mechanical"><img src="imgs/settings-48.png" alt=""></div>
                        <div class="icon " id="electrical"><img src="imgs/flash.png" alt=""></div>
                        <div class="icon " id="civil"><img src="imgs/constructor-with-hard-hat-prot.png" alt=""></div>
                        <div class="icon " id="archticture"><img src="imgs/cityscape.png" alt=""></div>
   <div class="icon " id="pharmacy"><img src="imgs/pharmacy.png" style="width40px;height:40px"  alt=""></div>
     <div class="icon " id="non-tech"><img src="imgs/non-tech.png"  style="width40px;height:40px" alt=""></div>
                    
        </section>
        

        <div class="row preferences-box">
<div class="alert alert-danger" role="alert" style="width:90%;margin-left:20px; margin-top:20px;">
  *The company you will select at first will be your first Preference and the second one will be your second Preference
</div>
<ol class="breadcrumb" style="width:90%;margin-left:20px; margin-top:20px;">

  <li class="active"><h3>Now you are at <span  id="var-text" style="font-weight:bold; color:red">Preparatory</span> Section</h3></li>
</ol>
          <ul  >
       <?php require_once'includes/routes.inc.php' ?>
          </ul>
        </div>

    </section>
    <section class="pst" style="margin-left: 8%" id="s-phase1">
        <div class="clock-container "> <!-- contains clock -->
            <div style="background-color:transparent; right:0px; top:70px; position:fixed; z-index:10000">

                <div class="clock" ></div>

                </div>
        </div>
        <div>
            <?php if(hasFullTime($id,30)==='FRESH'){?>
                  <div id="instructions"> 
                        <ol class="col-lg-12 col-md-12" >
                          <h1 align="center" > PST Instructions </h1>
                          <h3 align="center" style="color:#D60126;">Please read and understand the following instructions carefully <br/>  </h3>                        
                          <br>
                          <li> Exam will start "immediately" after you click startQuiz </li>
                          <li style="color:#D60126;">Refreshing or closing the test after 30 minutes prevents you from entering it again !! </li>
                          <li> Number of questions: 40 MCQs</li>
                          <li>Exam time: 30 mins </li> 
                          Bring a notebook, pen, and calculator <br/>
                          <span style="color:#D60126;" >you can enter the online test only from desktop or laptop computer</span>
                              <br>
                              <br>
                                <!--
                                <label id="codel"for="code">Login Code</label>
                                <input required type="text" class="form-control" id="code" name="code" placeholder="Enter your code"> -->
              <button  type="submit" onclick="startQuiz(event,<?php echo $id;?>)" class="btn btn-danger btn-large" value="submit" name="submit">Start Quiz</button>
                              
                              <br>
                              
                        </ol>
                  </div>
                  <div id="pst-ques">
                  <?php }
                  else{ //user had seen exam
                    if(hasFullTime($id,30)){ //over time ?>
                          <div class="row">
                <div class="col s12 m6" style="margin-left: 10%;">
                  <div class="card blue-grey darken-1" >
                    <div class="card-content white-text" style=" background: #EEEEEE">
                      <p style="color: #000"> Thank You , You had been tested .</br>Stay tuned for results.</p>
                    </div>
                    
                  </div>
                </div>
              </div>
                       
             <?php }
                    else{ // not over timed
                    ?>
                    <script type="text/javascript">
                        clock = $('.clock').FlipClock(1800, { //1800 secs = 30 mins
                            clockFace: 'MinuteCounter',
                            countdown: true,
                            autoStart: true,
                            callbacks: {
                                stop: function(){
                                    $( "#quiz" ).submit();
                                }
                            }
                        });
                    </script>
                    <?php
                     require_once'includes/quiz.php';
                     require_once'includes/pst.php';
                    }
                  }
                  ?>
                  </div>
        </div>
    </section>
    <section class="interview" id="s-phase2">
        <!-- FINISH A GOOD DESIGN HERE !! -->
    </section>
    <section class="congrate" id="s-phase3">
        <!-- FINISH A GOOD DESIGN HERE !! -->
    </section>
</section> <!-- contains dynamic sections -->
<!--
 <section>

    <nav>
        <ol class="cd-breadcrumb triangle">
            <li><a href="#0">Home</a></li>
            <li><a href="#0">Gallery</a></li>
            <li><a href="#0">Web</a></li>
            <li class="current"><em>Project</em></li>
        </ol>
    </nav>
</section>
-->


 <script src="js/modernizr.js"></script> 
 <script src="js/jquery.nicescroll.min.js"></script>
 <script type="text/javascript" src="js/materialize.min.js"></script>
<script src="js/script.js"></script>
<script src="js/start.js"></script>


</body>
</html>