function startQuiz(event,id){
	event.preventDefault();
		$.post('includes/start_pst.php',{id:id},function(pst){
			$('#instructions').remove();
			$('#pst-ques').html(pst);
			$(".clock-container").show();
			clock = $('.clock').FlipClock(1800, { //1800 secs = 30 mins
	            clockFace: 'MinuteCounter',
	            countdown: true,
	            autoStart: true,
	            callbacks: {
	            	stop: function(){
		            	$( "#quiz" ).submit();
		          	}
	            }
        	});
		});
}