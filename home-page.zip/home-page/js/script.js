/* func stages is very important ,
it takes num then decides what stage are we in(apply or pst or ..) */ 
function stages(num){
    var label = $("#phase"+num);
    label.addClass("current");
    label.siblings("").removeClass("current");
    var section = $("#s-phase"+num);
    section.show();
    section.siblings().hide();
};

var n = 2; // applies number
var first_route="";
var second_route="";
function applying(route_name,id){
  if (n===2) {
    first_route = route_name;
    n = n-1;
    $("#route-"+id).remove();
  }
  else if(n===1){
    second_route = route_name;
    n = n-1;
    $("#route-"+id).remove();
    $.post("includes/routes_users.php",{
      r1:first_route,
      r2:second_route
    },function() {
      stages(1);
    });
    
  }
};
$(document).ready(function(){


$.get("includes/stage.php",function(s){
  stages(s);
});


  // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
  $('.modal').modal();

  $(function (){

    'use strict';

    $(".preferences-box").niceScroll({
        
        cursorcolor:'#b50101',
        cursorwidth:8,
        cursorborder:'1px solid #b50101'          

    });
  });


  $("#electrical,#electrical-xs").click(function(){

      	$(".civil").hide();
      	$(".mech").hide();
      	$(".arch").hide();
        $(".pharmacy").hide();
        $(".non-tech").hide();
        $(".elec").show(); 

        document.getElementById("var-text").innerHTML = "Electrical";
        
  });

  $("#mechanical,#mechanical-xs").click(function(){
      	$(".civil").hide();
      	$(".elec").hide();
      	$(".arch").hide(); 
        $(".pharmacy").hide();
        $(".non-tech").hide();
        $(".mech").show();

        document.getElementById("var-text").innerHTML = "Mechanical";

  });

  $("#civil,#civil-xs").click(function(){

      	$(".elec").hide();
      	$(".mech").hide();
      	$(".arch").hide();
        $(".pharmacy").hide();
        $(".non-tech").hide();
        $(".civil").show(); 


        document.getElementById("var-text").innerHTML = "Civil";



  });


  $("#archticture,#archticture-xs").click(function(){
      	$(".civil").hide();
      	$(".mech").hide();
      	$(".elec").hide();
        $(".pharmacy").hide();
        $(".non-tech").hide();
        $(".arch").show();

  document.getElementById("var-text").innerHTML = "Archticture";
  });

  $("#pharmacy,#pharmacy-xs").click(function(){
      	$(".civil").hide();
      	$(".mech").hide();
      	$(".elec").hide();
        $(".arch").hide();
        $(".non-tech").hide();
        $(".pharmacy").show();

  document.getElementById("var-text").innerHTML = "Pharmacy";

  }); 

 $("#non-tech,#non-tech-xs").click(function(){
      	$(".civil").hide();
      	$(".mech").hide();
      	$(".elec").hide();
        $(".pharmacy").hide();
        $(".arch").hide();
        $(".non-tech").show();

  document.getElementById("var-text").innerHTML = "non-techniclal";

  });

  $("#all,#all-xs").click(function(){


        $(".arch").show();
      	$(".civil").show();
      	$(".mech").show();
        $(".pharmacy").show();
        $(".non-tech").show();
      	$(".elec").show(); 

document.getElementById("var-text").innerHTML = "Preparatory";
  });



});