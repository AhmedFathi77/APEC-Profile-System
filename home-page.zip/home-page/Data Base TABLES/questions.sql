-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2016 at 07:58 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apec_final`
--

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `correct` varchar(100) NOT NULL,
  `question` text NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `type` varchar(100) NOT NULL,
  `answer1` varchar(100) NOT NULL,
  `answer2` varchar(100) NOT NULL,
  `answer3` varchar(100) NOT NULL,
  `answer4` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONS FOR TABLE `questions`:
--

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `category`, `correct`, `question`, `image`, `type`, `answer1`, `answer2`, `answer3`, `answer4`) VALUES
(1, 'easyenglish', 'was nobody', 'The party was a disaster\r\nThere, ______ there!', NULL, '1', 'was no body', 'was anybody', 'was nobody', 'was somebody'),
(2, 'easyenglish', 'don’t you?', 'you live upstairs from me, ______?', NULL, '1', 'do you?', 'are you?', 'don’t you?', 'didn’t you?'),
(3, 'easyenglish', 'on', 'she has her German classes______ Tuesday.', NULL, '1', 'in', 'on', 'by', 'at'),
(4, 'easyenglish', 'attached', 'my children became ______to their friends more than before.', NULL, '1', 'attracted', 'attached', 'attacked', 'adhered'),
(5, 'easyenglish', 'come out', 'the government’s newspapers ______Daily.', NULL, '1', 'publish', 'release', 'print', 'come out'),
(6, 'easyenglish', 'a few', 'I still have ______ Things to do.', NULL, '1', 'a little', 'a few', 'one', 'much'),
(7, 'easyenglish', 'is being', 'our car ______ repaired this week', NULL, '1', 'is being', 'is', 'has', 'will'),
(8, 'easyenglish', 'of', 'You are supposed to take this medicine and you will get rid ________ the bad cold.', NULL, '1', 'at', 'from', 'over', 'of'),
(9, 'easyenglish', 'ripe', 'The grapes are now ________ enough to be picked.', NULL, '1', 'ripe', 'mature', 'ready', 'advanced'),
(10, 'easyenglish', 'for', 'That''s what I would like ________ Christmas.', NULL, '1', 'for', 'on', 'in', 'at'),
(11, 'easyenglish', 'directly', 'As a newspaper reporter she always wanted to get information (at first hand).', NULL, '1', 'quickly', 'slowly', 'easily', 'directly'),
(12, 'easyenglish', 'fully occupied with', 'He''s (up to his ears) in work and cannot possibly see you now.', NULL, '1', 'fully occupied with', 'very interested in', 'not involved with', 'concerned with'),
(13, 'easyenglish', 'up', 'Plans have already been drawn .......to deal with such situations.', NULL, '1', 'over', 'through', 'up', 'into'),
(14, 'easyenglish', 'too slowly', 'Enrica seems very desperate because she is typing ......... to complete the monthly sales report.', NULL, '1', 'too slowly', 'much slowly', 'slow enough', 'rather slowly'),
(15, 'easyenglish', 'which was', 'Susen failed all her exams, ______ a big surprise.', NULL, '1', 'that was', 'was', 'which was', 'where was'),
(16, 'easyenglish', 'in', 'I can''t park here. That motorbike is ____ the way.', NULL, '1', 'on', 'in', 'up', 'across'),
(17, 'easyenglish', 'similar-looking', 'We''ve got three very _____ cats.', NULL, '1', 'alike-looking', 'similar-looking', 'same', 'alike'),
(18, 'easyenglish', 'so', 'Prices are too high and they will remain _____ until inflation comes down.', NULL, '1', 'so', 'there', 'that', 'as'),
(19, 'easyenglish', 'accused of', 'In the course of the meeting, Mr. Smith was _____ mishandling funds.', NULL, '1', 'praised for', 'denied', 'accused of', 'informed by'),
(20, 'easyenglish', 'a', 'I bet your wife could tell _____ good few stories about you.', NULL, '1', 'some', 'a', 'so', 'much'),
(21, 'easyenglish', 'to make', 'I stopped _____ a phone call on my way home.', NULL, '1', 'making', 'for making', 'to make', 'for make'),
(22, 'easyenglish', 'whether', 'We''ll need to discuss _____ we should close the shop.', NULL, '1', 'about', 'that', 'what', 'whether'),
(23, 'easyenglish', 'you mean', 'I''m sorry, I can''t see what ________ .', NULL, '1', 'can you mean', 'you are meaning', 'do you mean', 'you mean'),
(24, 'easyenglish', 'some new furniture', 'My husband and I bought _______ last week.', NULL, '1', 'some new furniture', 'a lot of new furniture', 'any new furniture', 'pieces of new furnitures'),
(25, 'easyenglish', 'made', 'The promises you have _____ will have to be kept.', NULL, '1', 'been done', 'done', 'making', 'made'),
(26, 'mediumenglish', '', 'I saw a________ of cows in the field.', NULL, '1', '', '', '', ''),
(27, 'mediumenglish', 'group', 'herd', NULL, '1', 'herd', 'swarm', 'flock', ''),
(28, 'mediumenglish', 'would win', 'I really thought that my team ________.', NULL, '1', 'will win', 'would have won', 'would win', 'win'),
(29, 'mediumenglish', 'may have gone', 'I can’t say for sure, but I think he _____back to Cairo.', NULL, '1', 'may gone', 'might gone', 'should to go', 'may have gone'),
(30, 'mediumenglish', 'sold', 'many goods _____ In Africa are made in china.', NULL, '1', 'sold', 'which sold', 'selling', 'are sold'),
(31, 'mediumenglish', 'had left', 'when I woke up, my father_____ So I didn’t see him.', NULL, '1', 'left', 'had left', 'was leaving', 'left'),
(32, 'mediumenglish', 'with', 'it is very wonderful to know that some types of ice cream are made _____ wood products.', NULL, '1', 'of', 'from', 'with', 'in'),
(33, 'mediumenglish', 'get', 'if you mix yellow and blue , you _____ green.', NULL, '1', 'gets', 'will get', 'can get', 'get'),
(34, 'mediumenglish', 'to join', 'I would prefer _____ a sports club.', NULL, '1', 'join', 'to join', 'joining', 'to joining'),
(35, 'mediumenglish', 'at', 'The person refused to grovel _________ the feet of his master.', NULL, '1', 'about', 'by', 'at', 'on'),
(36, 'mediumenglish', 'abou', 'The father was anxious __________ the safety of his daughter.', NULL, '1', 'for', 'at', 'about', 'with'),
(37, 'mediumenglish', 'black and white', 'Now that they have read it in ......., they believe me.', NULL, '1', 'red and blue', 'blue and red', 'white and black', 'black and white'),
(38, 'mediumenglish', 'roam', 'He soon retired and will finally have enough time to .......over the country.', NULL, '1', 'mosey', 'roam', 'gad', 'stride'),
(39, 'mediumenglish', 'to make a fool of you', 'You shouldn''t sign there I think he''s about to (make a monkey out of you).', NULL, '1', 'to make a fool of you', 'to make you feel stupid', 'to make you lose money', 'to make you lose interest'),
(40, 'mediumenglish', 'being alone all day', 'I can''t get used to __________ .', NULL, '1', 'be alone all day.', 'that I''m alone all day.', 'being alone all day.', 'I was alone all day'),
(41, 'mediumenglish', 'them', 'If anybody wants to talk to me, tell ____ to call back later.', NULL, '1', 'her', 'me', 'him', 'them'),
(42, 'mediumenglish', 'nonetheless', 'Their business hasn''t taken off as expected, ____ , they are happy that the number of their customers is increasing.', NULL, '1', 'furthermore', 'inasmuch as', 'nonetheless', 'moreover'),
(43, 'mediumenglish', 'to have been', 'Mrs. Brown''s death came as no surprise, as she was said _____ ill for a long time.', NULL, '1', 'to be', 'to have been', 'she had been', 'she was'),
(44, 'mediumenglish', 'regards', 'I don''t dislike the building. Now, as _____ the neighborhood, I do have concerns.', NULL, '1', 'about', 'well', 'regards', 'in'),
(45, 'mediumenglish', 'haven''t considered the users', 'The problem with this product is that the designers ______ .', NULL, '1', 'considered by the users', 'haven''t considered the users', 'inadequate', 'inadequately trained'),
(46, 'mediumenglish', 'Remember', ' _____ me to your mother when you are in London.', NULL, '1', 'Tell', 'Remind', 'Remember', 'Greet'),
(47, 'mediumenglish', 'Should you need', 'you need', NULL, '1', 'You should need', 'Unless you need', 'You will need', ''),
(48, 'mediumenglish', 'herd', 'I saw a________ of cows in the field.', NULL, '1', 'group', 'herd', 'swarm', 'flock'),
(49, 'mediumenglish', 'would win', 'I really thought that my team ________.', NULL, '1', 'will win', 'would have won', 'would win', 'win'),
(50, 'mediumenglish', 'may have gone', 'I can’t say for sure, but I think he _____back to Cairo.', NULL, '1', 'may gone', 'might gone', 'should to go', 'may have gone'),
(51, 'mediumenglish', 'sold', 'many goods _____ In Africa are made in china.', NULL, '1', 'sold', 'which sold', 'selling', 'are sold'),
(52, 'mediumenglish', 'had left', 'when I woke up, my father_____ So I didn’t see him.', NULL, '1', 'left', 'had left', 'was leaving', 'left'),
(53, 'mediumenglish', 'with', 'it is very wonderful to know that some types of ice cream are made _____ wood products.', NULL, '1', 'of', 'from', 'with', 'in'),
(54, 'mediumenglish', 'get', 'if you mix yellow and blue , you _____ green.', NULL, '1', 'gets', 'will get', 'can get', 'get'),
(55, 'mediumenglish', 'to join', 'I would prefer _____ a sports club.', NULL, '1', 'join', 'to join', 'joining', 'to joining'),
(56, 'mediumenglish', 'at', 'The person refused to grovel _________ the feet of his master.', NULL, '1', 'about', 'by', 'at', 'on'),
(57, 'mediumenglish', 'abou', 'The father was anxious __________ the safety of his daughter.', NULL, '1', 'for', 'at', 'about', 'with'),
(58, 'mediumenglish', 'black and white', 'Now that they have read it in ......., they believe me.', NULL, '1', 'red and blue', 'blue and red', 'white and black', 'black and white'),
(59, 'mediumenglish', 'roam', 'He soon retired and will finally have enough time to .......over the country.', NULL, '1', 'mosey', 'roam', 'gad', 'stride'),
(60, 'mediumenglish', 'to make a fool of you', 'You shouldn''t sign there I think he''s about to (make a monkey out of you).', NULL, '1', 'to make a fool of you', 'to make you feel stupid', 'to make you lose money', 'to make you lose interest'),
(61, 'mediumenglish', 'being alone all day', 'I can''t get used to __________ .', NULL, '1', 'be alone all day.', 'that I''m alone all day.', 'being alone all day.', 'I was alone all day'),
(62, 'mediumenglish', 'them', 'If anybody wants to talk to me, tell ____ to call back later.', NULL, '1', 'her', 'me', 'him', 'them'),
(63, 'mediumenglish', 'nonetheless', 'Their business hasn''t taken off as expected, ____ , they are happy that the number of their customers is increasing.', NULL, '1', 'furthermore', 'inasmuch as', 'nonetheless', 'moreover'),
(64, 'mediumenglish', 'to have been', 'Mrs. Brown''s death came as no surprise, as she was said _____ ill for a long time.', NULL, '1', 'to be', 'to have been', 'she had been', 'she was'),
(65, 'mediumenglish', 'regards', 'I don''t dislike the building. Now, as _____ the neighborhood, I do have concerns.', NULL, '1', 'about', 'well', 'regards', 'in'),
(66, 'mediumenglish', 'haven''t considered the users', 'The problem with this product is that the designers ______ .', NULL, '1', 'considered by the users', 'haven''t considered the users', 'inadequate', 'inadequately trained'),
(67, 'mediumenglish', 'Remember', ' _____ me to your mother when you are in London.', NULL, '1', 'Tell', 'Remind', 'Remember', 'Greet'),
(68, 'mediumenglish', 'Should you need', '_____ any further information, do not hesitate to contact me.', NULL, '1', 'Should you need', 'You should need', 'Unless you need', 'You will need'),
(69, 'hardenglish', 'sauntering', 'As Brian is having his summer vacation, he is_____ about the village all day long.', NULL, '1', 'striding', 'staggering', 'walking', 'sauntering'),
(70, 'hardenglish', 'strode', 'As it had no choice in trying to escape from the vulture, the doe _____quickly over the streamlet.', NULL, '1', 'strode', 'paced', 'strayed', 'meandered'),
(71, 'hardenglish', 'inquisitive', 'In a child, curiosity normally suggests intelligence and is welcomed. but an _____ adult is best avoided.', NULL, '1', 'inquisitive', 'impartial', 'indecisive', 'indulgent'),
(72, 'hardenglish', 'appropriate', 'In view of the severe economic recession, his appointment to this office was regarded as highly_____ .', NULL, '1', 'persuasive', 'refutable', 'appropriate', 'considerable'),
(73, 'hardenglish', 'A catastrophe was imminent.', '"I felt the wall of the tunnel shiver. The master alarm squealed through my earphones. Almost simultaneously, Jack yelled down to me that there was a warning light on. Fleeting but spectacular sights snapped into out of view, the snow, the shower of debris, the moon, looming close and big, the dazzling sunshine for once unfiltered by layers of air. The last twelve hours before re-entry were particular bone-chilling. During this period, I had to go up into the command module. Even after the fiery re-entry splashing down in 81o water in the south pacific, we could still see our frosty breath inside the command module." \r\nWhich one of the following reasons would one consider as more as possible for the warning lights to be on?', NULL, '1', 'There was a shower of debris.', 'Jack was yelling.', 'A catastrophe was imminent.', 'The moon was looming close and big.'),
(74, 'hardenglish', 'played', 'I_____ squash for 2 years. Now I play tennis.', NULL, '1', 'was playing', 'played', 'have played', 'had played'),
(75, 'hardenglish', 'had had time', 'If I ______ to feed the dog, it wouldn''t be starving now.', NULL, '1', 'have had time', 'have time', 'had had time', 'never have time'),
(76, 'hardenglish', 'was his recognition', 'Part of the reason Chris wanted to apply for the job _____ that employees were given plenty of room to grow within the company.', NULL, '1', 'he had recognized', 'realizing', 'was his recognition', 'was mainly'),
(77, 'hardenglish', 'foot', 'I think I put my _____ in it when I asked Jane about her ex-husband.', NULL, '1', 'thought', 'elbow', 'foot', 'nose'),
(78, 'hardenglish', 'gadded', 'Her friends left her all alone in a strange town and she .......about unaccompanied all day long.', NULL, '1', 'staggered', 'stalked', 'strayed', 'gadded'),
(79, 'hardenglish', 'all the more', 'She doesn''t reveal much about herself, and is _____ fascinating for it.', NULL, '1', 'as', 'the same', 'all the more', 'the more'),
(80, 'hardenglish', 'nice a', 'He''s too _____ person to say no.', NULL, '1', 'nice a', 'nice', 'a nice', 'so nice'),
(81, 'easyiq', 'Hat', 'A hand to a glove is like a head to a:', NULL, '1', 'Hair', 'Hat', 'Skin', 'Sweat'),
(82, 'easyiq', '1/16', 'Which number should come next? 64, 16, 4, 1, ¼?', NULL, '1', '1/16', '1/12', '1/8', '1/2'),
(83, 'easyiq', 'leaf', 'Forest is to tree as tree is to?', NULL, '1', 'plant', 'leaf', 'branch', 'mangrove'),
(84, 'easyiq', '5th', 'You are in a race and you just overtook the 5th player, what is your place now?', NULL, '1', '4th', '3rd', '5th', '6th'),
(85, 'easyiq', 'none of the above', 'An electric train is travelling from New York to Vegas, and is moving against the direction of the wind which is north east. What is the direction of the fumes emitted from the chimney?', NULL, '1', 'north east', 'south east', 'south west', 'none of the above'),
(86, 'easyiq', 'Cannot be resolved', '"THIS STATEMENT IS FALSE"\r\nWhich of the following applies to the above statement?', NULL, '1', 'True', 'False', 'Cannot be resolved', 'Null'),
(87, 'easyiq', 'Lotus', 'Find the odd one out?', NULL, '1', 'Rose', 'Lotus', 'Jasmine', 'Dahlia'),
(88, 'easyiq', 'Electricity', 'Water is to a pipe as……?  Is to a wire.', NULL, '1', 'Cord', 'Electricity', 'Heat', 'Gas'),
(89, 'easyiq', 'He is my father', 'I’m a male. If Albert''s son is my son''s father, what is the relationship between Albert and me?', NULL, '1', 'He is my father', 'He is my brother', 'He is my uncle', 'He isn’t related to me'),
(90, 'easyiq', 'B', 'What comes next in the sequence?', 'iq10.jpg', '1', 'A', 'B', 'C', 'Null'),
(91, 'easyiq', '10.25', 'If you have $40.50, you give $25.25 to a homeless person, spend $5 on a new skateboard, and shove $4.20 in your pocket, how much do you have left?', NULL, '1', '5.5', '6.05', '10.25', '4.20'),
(92, 'easyiq', 'The peanut', 'Which object will fall faster? An 8 x 11 piece of paper or a peanut? Both weights the same amount.', NULL, '1', 'The piece of paper', 'The peanut', 'It is impossible to know', 'Null'),
(93, 'easyiq', 'Marts are six times as long as Worbs', 'Marts are twice as long as Mops. Mops are three times as long as Worbs. That means that:', NULL, '1', 'Worbs are six times as long as Marts', 'Marts are six times as long as Worbs', 'Marts are eight times as long as Worbs', 'Worbs are eight times as long as Marts'),
(94, 'easyiq', '5', 'Choose the number that is 1/4 of 1/2 of 1/5 of 200?', NULL, '1', '5', '10', '15', '20'),
(95, 'easyiq', 'B', 'Which one of the designs is least like the other three?', 'iq15.jpg', '1', 'A', 'B', 'C', 'D'),
(96, 'easyiq', '7', 'If Bob sold 35 apples in a working week, what is the average number of apples he sells each day?', NULL, '1', '5', '3', '7', '10'),
(97, 'mediumiq', '12.5', 'A man’s speed with the current is 15km/hour, and the speed of the current is 2.5km/hour. What is the man’s speed against the current?', NULL, '1', '8.5', '9', '10', '12.5'),
(98, 'mediumiq', 'B', 'Observe the pattern: T/3/Q/6/N/9/K/12/H/15/E/18/? What comes next in this pattern?', NULL, '1', '21', 'D', 'B', 'c'),
(99, 'mediumiq', '6', 'If two typists can type two pages in two minutes, how many typists will it take to type 18 pages in six minutes?', NULL, '1', '3', '6', '12', '36'),
(100, 'mediumiq', '10 meters', 'Two men, starting at the same point, walk in opposite directions for 4 meters, turn left and walk another 3 meters. What is the distance between them?', NULL, '1', '2 meters', '6 meters', '10 meters', '12.5 meters'),
(101, 'mediumiq', '21:00', 'If it were 2 hours later, it would be half as long until midnight as it would be if it were an hour later. What time is it now?', NULL, '1', '20:00', '21:00', '22:00', '23:30'),
(102, 'mediumiq', 'True', 'STATEMENT: All WONGS are PLATS. No PLATS are GORTS\r\nCONCLUSION: No GORTS are WONGS\r\nthe conclusion is', NULL, '1', 'True', 'Null', 'False', 'Not determinable'),
(103, 'mediumiq', '3236', 'Which one of the five choices makes the best comparison? LIVED is to DEVIL as 6323 is to:', NULL, '1', '6232', '3236', '3326', '6332'),
(104, 'mediumiq', 'Country', 'If you rearrange the letters "ANLDEGN," you would have the name of a (n):', NULL, '1', 'Country', 'State', 'City', 'Animal'),
(105, 'mediumiq', 'Rocket', 'NASA received three messages in a strange language from a distant planet. The scientists studied the messages and found that "Necor Buldon Slock" means "Danger Rocket Explosion" and "Edwan Mynor Necor" means "Danger Spaceship Fire" and "Buldon Gimilzor Gondor" means "Bad Gas Explosion". What does "Slock" mean?', NULL, '1', 'Danger', 'Explosion', 'Rocket', 'Gas'),
(106, 'mediumiq', 'C lied, B cheated', 'Four (A, B, C and D) suspects were interrogated:\r\nA said: C won''t cheat unless B cheated.\r\nB said: Either A or B cheated.\r\nC said: B didn''t cheat, I cheated.\r\nD said: B cheated.\r\nOnly one person is lying, which of the following is correct:', NULL, '1', 'C lied, B cheated', 'B lied, B cheated', 'A lied, C cheated', 'D lied, C cheated'),
(107, 'mediumiq', '101', 'Sue is both the 50th best and the 50th worst student at her school. How many students attend her school?', NULL, '1', '75', '99', '100', '101'),
(108, 'mediumiq', 'Joe is older than Bob', 'John is older than Bob, Bob is younger than Steve, Steve is older than Joe, Joe is older than John, Ray is younger than Jim\r\nWhich conclusion is definitely accurate?', NULL, '1', 'Bob is older than Ray', 'Joe is older than Bob', 'Joe is older than Jim', 'None of the above'),
(109, 'mediumiq', '24', 'Mary, who is sixteen years old, is four times as old as her brother. How old will Mary be when she is twice as old as her brother?', NULL, '1', '20', '24', '25', '28'),
(110, 'mediumiq', '8', 'Which one of the numbers does not belong in the following series?\r\n2 , 3 , 6 , 7 , 8 , 14 , 15 , 30', NULL, '1', '3', '7', '8', '30'),
(111, 'mediumiq', '118 m', 'Tom has a new set of golf clubs. Using a club 8, the ball travels an average distance of 100 meters. Using a club 7, the ball travels an average distance of 108 meters. Using a club 6, the ball travels an average distance of 114 meters. How far will the ball go if Tom uses a club 5?', NULL, '1', '122 m', '120 m', '118 m', '116 m'),
(112, 'mediumiq', '6', 'There are 10 people at a party. 3 leave, 2 fall asleep, and one dies from a heart attack. How many people are left?', NULL, '1', '6', '5', '7', '4'),
(113, 'mediumiq', '8, 3925211,129', 'Which of the following character strings is the closest match to 8,392,211,109?', NULL, '1', '8,382,311,119', '8, 3925211,129', '8,39,2211,208', '8, 329,211,108'),
(114, 'mediumiq', 'D', 'Which is the odd one out?', 'iq34.jpg', '1', 'A', 'B', 'C', 'D'),
(115, 'mediumiq', 'It is impossible to know', 'If Kentwood is closer to Marshall than Bershire, and Marshall is closer to Kentwood than Bershire, then Bershire is closer to:', NULL, '1', 'Null', 'Kentwood', 'Marshall', 'It is impossible to know'),
(116, 'mediumiq', '21', 'Which number should come next in the series 1, 2, 3, 5,8, 13,….?', NULL, '1', '16', '23', '21', '19'),
(117, 'mediumiq', 'She liked pink flowers more than yellow flowers', 'Mary loved pink flowers more than she loved red ones. She didn''t like orange flowers at all, and while she liked yellow flowers, she couldn''t say that she really loved them. Which of these is true?', NULL, '1', 'She liked red flowers less than orange flowers', 'She liked yellow flowers more than red flowers', 'She liked pink flowers more than yellow flowers', 'She liked orange flowers more than pink flowers'),
(118, 'mediumiq', '100', 'If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?', NULL, '1', '50', '100', '150', '200'),
(119, 'mediumiq', '49', 'What number is missing from the sequence?\r\n4,9,16,25,36,x,64', NULL, '1', '44', '49', '52', '56'),
(120, 'mediumiq', '698 : 62', '329:15\r\n746:34\r\nWhich numbers below have the same relationship to each other as the two sets of numbers above?', NULL, '1', '287 : 22', '698 : 62', '382 : 12', '749 : 35'),
(121, 'hardiq', 'bloat', '6121135 is to flame as 21215120 is to?', NULL, '1', 'voice', 'bald', 'bloat', 'castle'),
(122, 'hardiq', 'Monday', 'The day after the day after tomorrow is four days before Monday. What day is it today?', NULL, '1', 'Tuesday', 'Monday', 'Thursday', 'Friday'),
(123, 'hardiq', '132', 'At a conference-e, 12 members shook hands with each other before & after the meeting. How many total number of handshakes occurred?', NULL, '1', '132', '145', '144', '121'),
(124, 'hardiq', 'Biunke', 'Three Eskimos who had returned after a long and dangerous trek to another Inuit, settlement were relating details of their arduous journey to their welcoming friends.\r\nAnuke said "We were harassed by wolves and chased by polar bears".\r\nBinuke said "Our meals consisted mainly of penguin eggs and salmon". \r\nKanyuke said "We saw numerous walruses and seals".\r\nOne of them was lying --- Who?', NULL, '1', 'anuke', 'Biunke', 'Kayunke', 'None of them'),
(125, 'hardiq', 'Label on the back, read ahoy', 'Sloppy Joe is aptly named.  He has a T-shirt that has a label attached to the inside of the front part of his right sleeve.  The brand name on the label reads "AHOY".\r\nHe turned the T-shirt inside out and put it on back to front.   Where now the label is and what does it read?', NULL, '1', 'Label on the front, read ahoy', 'Label on the back, read ahoy', 'Label on the front, read yoha', 'Label on the back, read yoha'),
(126, 'hardiq', 'While green is not Y, red is not X.', 'When red is X, green is Y. When green is not Y, blue is Z. But blue is never Z as long as red is X. Therefore, which one of these statements is correct?', NULL, '1', 'Null', 'While blue is Z, green is Y.', 'While red is not X, blue is not Z.', 'While green is not Y, red is not X.'),
(127, 'hardiq', 'A''s son', 'A, B, C, D, E, F and G are members of a family consisting of four adults and three children, two of whom, F and G are girls. A and D are brothers and A is a doctor. E is an engineer married to one of the brothers and has two children. B is married to D and G is their child. Who is C?', NULL, '1', 'E''s daughter', 'F''s father', 'G''s brother', 'A''s son'),
(128, 'hardiq', 'B', 'What does the resulting cube look like if you fold this cube together?', 'iq48.jpg', '1', 'A', 'B', 'C', 'D'),
(129, 'hardiq', '42', 'What is the next number in the series? \r\n1,3,8,19,….', NULL, '1', '38', '42', '41', '40'),
(130, 'hardiq', 'D', 'The Missed Shape is :', 'iq50.jpg', '1', 'A', 'B', 'C', 'D'),
(131, 'hardiq', 'Conserved', 'The institution houses collections of objects of artistic, historic and scientific interest, and displayed for the edification and enjoyment of the public. One word has been removed from the passage above. Select that word from the choice below and reinstate it in its correct place in the passage.', NULL, '1', 'Permanent', 'Produced', 'Conserved', 'accumulated'),
(132, 'hardiq', '70 & 76', 'In the two numerical sequences below, one number that appears in the top sequence should appear in the bottom sequence and vice versa. Which two numbers should be changed round? \r\n88, 84, 70, 60 & 97, 91, 82, 76', NULL, '1', '88 & 82', '91 & 70', '70 & 76', '60 & 91'),
(133, 'hardiq', '4', 'You have 68 cubic blocks. What is the minimum number that needs to be taken away to construct a solid cube with none left over?', NULL, '1', '4', '3', '5', '2'),
(134, 'hardiq', '23', 'Mary had a number of cookies. After eating one, she gave half the remaining to her sister. After eating another cookie, she gave half of what was left to her brother. Mary now had only five cookies left. How many cookies did she start with?', NULL, '1', '11', '22', '23', '43'),
(135, 'hardiq', '2', 'Select the correct figure.', 'iq55.jpg', '1', '1', '2', '3', '4'),
(136, 'easylogic', 'true', 'Blueberries cost more than strawberries.\r\nBlueberries cost less than raspberries.\r\nRaspberries cost more than both strawberries and blueberries.\r\nIf the first two statements are true, the third statement is', NULL, '1', 'true', 'false', 'uncertain', 'Null'),
(137, 'easylogic', 'Bear', 'Choose the word which is different from the rest.', NULL, '1', 'Lion', 'Bear', 'Tiger', 'Leopard'),
(138, 'easylogic', 'bud', 'Which word does NOT belong with the others?', NULL, '1', 'tulip', 'rose', 'bud', 'daisy'),
(139, 'easylogic', 'theology', 'which word does not belong to others', NULL, '1', 'biology', 'chemistry', 'theology', 'zoology'),
(140, 'easylogic', '3', 'Choose the picture that would go in the empty box so that the two bottom pictures are related in the same way as the top two are related.', 'logic5.jpg', '1', '1', '2', '3', '4'),
(141, 'easylogic', 'false', 'Tanya is older than Eric,cliff is older than Tanya,Eric is older than cliff.\r\nThe third statement is:', NULL, '1', 'true', 'false', 'not certain', 'Null'),
(142, 'easylogic', 'true', 'All the trees in the park are flowering trees.Some of the trees in the park are the dogwoods.All dogwoods in the park are flowering trees.\r\nIf the first two statements are true, the third statement is:', NULL, '1', 'true', 'false', 'not certain', 'Null'),
(143, 'easylogic', 'VIJ', 'SCD, TEF, UGH, ____, WKL', NULL, '1', 'CMN', 'UJI', 'VIJ', 'IJT'),
(144, 'easylogic', 'leaf', 'Forest is to tree as the  tree is to ?', NULL, '1', 'plant', 'leaf', 'branch', 'mangrove'),
(145, 'mediumlogic', 'Max', 'Children are in pursuit of a dog whose leash has broken. James is directly behind the dog. Ruby is behind James. Rachel is behind Ruby. Max is ahead of the dog walking down the street in the opposite direction. As the children and dog pass, Max turns around and joins the pursuit. He runs in behind Ruby. James runs faster and is alongside the dog on the left. Ruby runs faster and is alongside the dog on the right. Which child is directly behind the dog?', NULL, '1', 'James', 'Ruby', 'Rachel', 'Max'),
(146, 'mediumlogic', 'false', 'Middletown is north of Centerville.\r\nCenterville is east of Penfield.\r\nPenfield is northwest of Middletown.\r\nIf the first two statements are true, the third statement is', NULL, '1', 'true', 'false', 'uncertain', 'Null'),
(147, 'mediumlogic', 'water', 'choose the word that is a necessary part of (swimming)', NULL, '1', 'pool', 'bathing suit', 'water', 'Null'),
(148, 'mediumlogic', 'Both I and II follow', 'Statements: A bird in hand is worth two in the bush.\r\nConclusions:\n\r\nI.We should be content with what we have.\n\r\nII.We should not crave for what is not.', NULL, '1', 'Only conclusion I follows', 'Only conclusion II follows', 'Either I or II follows', 'Both I and II follow'),
(149, 'mediumlogic', 'Either I or II follows', 'Statements: Some papers are pens.The  Angle is a paper.\n\r\nConclusions:\n\r\nI.	Angle is not a pen.\n\r\nII.	Angle is a pen.', NULL, '1', 'Only conclusion I follows', 'Only conclusion II follows', 'Either I or II follows', 'Both I and II follow'),
(150, 'mediumlogic', 'True', 'Apartments in the Riverdale Manor cost less than apartments in The Gaslight Commons.\r\nApartments in the Livingston Gate cost more than apartments in the The Gaslight Commons.\r\nOf the three apartment buildings, the Livingston Gate costs the most.\r\nIf the first two statements are true, the third statement is:', NULL, '1', 'True', 'False', 'Uncertain', 'Null'),
(151, 'mediumlogic', 'VE7', 'In these series, you will be looking at both the letter pattern and the number pattern. Fill the blank in the middle of the series or end of the series.\n\r\nZA5, Y4B, XC6, W3D, _____', NULL, '1', 'E7V', 'V2E', 'VE5', 'VE7'),
(152, 'hardlogic', '132', 'At a conference, 12 members shook hands with each other before & after the meeting. How many total number of handshakes occurred?', NULL, '1', '132', '145', '144', '100'),
(153, 'hardlogic', 'nine', 'Nurse Kemp has worked more night shifts in a row than Nurse Rogers, who has worked five. Nurse Miller has worked fifteen night shifts in a row, more than Nurses Kemp and Rogers combined. Nurse Calvin has worked eight night shifts in a row, less than Nurse Kemp. How many night shifts in a row has Nurse Kemp worked?', NULL, '1', 'eight', 'nine', 'ten', 'eleven'),
(154, 'hardlogic', 'uncertain', 'All the tulips in Zoe''s garden are white.\n\r\nAll the pansies in Zoe''s garden are yellow.\n\r\nAll the flowers in Zoe''s garden are either white or yellow\n\r\n If the first two statements are true, the third statement is', NULL, '1', 'true', 'false', 'uncertain', 'Null'),
(155, 'hardlogic', 'uncertain', 'During the past year, Josh saw more movies than Stephen.\n\r\nStephen saw fewer movies than Darren.\n\r\nDarren saw more movies than Josh.\n\r\n If the first two statements are true, the third statement is', NULL, '1', 'true', 'false', 'uncertain', 'Null'),
(156, 'hardlogic', 'Haplresbo', 'Here are some words translated from an artificial language.\nhapllesh means cloudburst\n\r\nsrenchoch means pinball\n\r\nresbosrench means ninepin\n\r\n Which word could mean "cloud nine"?', NULL, '1', 'leshsrench', 'ochhapl', 'haploch', 'haplresbo'),
(157, 'hardlogic', 'Neither I nor II follows', 'The Prime Minister emphatically stated that his government will make every possible effort for uplifting of poor farmers and farmhands.\r\nConclusions:\r\nI.Except poor farmers and farmhands, all others have got the benefits of the fruits of development.\r\nII.No serious efforts have been made in the past for uplifting  of any section of the society.', NULL, '1', 'Only conclusion I follows', 'Only conclusion II follows', 'Either I or II follows', 'Neither I nor II follows'),
(158, 'hardlogic', 'Carter', 'Ms. Forest likes to let her students choose who their partners will be; however, no pair of students may work together more than seven class periods in a row. Adam and Baxter have studied together seven class periods in a row. Carter and Dennis have worked together three class periods in a row. Carter does not want to work with Adam. Who should be assigned to work with Baxter?', NULL, '1', 'Carter', 'Adam', 'Dennis', 'Forest'),
(159, 'easymath', '20,15', 'The area of a rectangular field is equal to 300 square meters. Its perimeter is equal to 70 meters. Find the length and width of this rectangle', NULL, '1', '20,15', '20,20', '20,30', 'Null'),
(160, 'easymath', '18,000', 'An electric motor makes 3,000 revolutions per minutes. How many degrees does it rotate in one second?', NULL, '1', 'Null', '20,000', '18,000', '22,000'),
(161, 'easymath', '34.8', 'The parallelogram shown in the figure below has a perimeter of 44 cm and an area of 64 cm2. Find angle T in degrees', 'math3.jpg', '1', '34.8', 'Null', '35.8', '36.8'),
(162, 'easymath', '47', 'What is the value of  u  in the sequence     2 , 7 , 14 , 23 , 34 , u ?', NULL, '1', '45', '46', '47', '53'),
(163, 'easymath', '32', 'How many subsets does the set {a, b, c, d, e} have?', NULL, '1', '2', '5', '10', '32'),
(164, 'easymath', '6', 'Which of the following is the Highest Common Factor of 18, 24 and 36?', NULL, '1', '6', '18', '36', '72'),
(165, 'easymath', '22', 'Look at this series: 36, 34, 30, 28, 24, ... What number should come next?', NULL, '1', '20', '22', '23', '26'),
(166, 'easymath', '9/20', 'Tickets numbered 1 to 20 are mixed up and then a ticket is drawn at random. What is the probability that the ticket drawn has a number which is a multiple of 3 or 5?', NULL, '1', '1/2', '2/5', '8/15', '9/20'),
(167, 'mediummath', '-0.4', 'If (0.2)x = 2 and log 2 = 0.3010, then the value of x to the nearest tenth is', NULL, '1', '0.6', '0.8', 'Null', '-0.4'),
(168, 'mediummath', '1/5', 'If 102y = 25, then 10-y equals', NULL, '1', '1/25', '1/5', '1/15', 'Null'),
(169, 'mediummath', '5000', 'The semicircle of area 1250 pi cm2 is inscribed inside a rectangle. The diameter of the semicircle coincides with the length of the rectangle. Find the area of the rectangle', NULL, '1', '5000', 'Null', '5500', '6000'),
(170, 'mediummath', 'x=20, y=14', 'In the figure below triangle OAB has an area of 72 and triangle ODC has an area of 288. Find x and y', 'math4.jpg', '1', 'X=20, y=20', 'x=20, y=30', 'x=20, y=14', 'Null'),
(171, 'mediummath', 'broke even', 'Mr. Jones sold two pipes at $1.20 each. Based on the cost, his profit one was 20% and his loss on the other was 20%. On the sale of the pipes,', NULL, '1', 'lost 4 cents', 'broke even', 'Null', 'lost 10 cents'),
(172, 'mediummath', '20', 'What percentage of numbers from 1 to 70 have 1 or 9 in the unit''s digit?', NULL, '1', '1', '14', '20', '21'),
(173, 'mediummath', '85 kg', 'The average weight of 8 person''s increases by 2.5 kg when a new person comes in place of one of them weighs 65 kg. What might be the weight of the new person?', NULL, '1', '76.5 kg', '85 kg', 'Data inadequate', 'None of these'),
(174, 'mediummath', '30', 'In a camp, there is a meal for 120 men or 200 children. If 150 children have taken the meal, how many men will be catered to with remaining meal?', NULL, '1', '20', '30', '40', '50'),
(175, 'mediummath', '14', 'The maximum slope of the curve\r\n-x3 + 6x3 + 2x + 1 is', NULL, '1', '14', '16', '19', '-13'),
(176, 'mediummath', '12', 'There are four bus lines between A and B; and three bus lines between B and C.\r\nThe number of ways a person can travel by bus from A to C by way of B will be', NULL, '1', '10', '12', '14', '24'),
(177, 'hardmath', 'None of this', 'Solve the following equation:', 'math1.jpg', '1', 'x=16/3', 'x=15/3', 'x=14/3', 'None of this'),
(178, 'hardmath', '67', 'Sum of three prime numbers is 100. If one of them exceeds another by 36, then one of the numbers is', NULL, '1', '7', '29', '41', '67'),
(179, 'hardmath', 'b^a', 'Given that  a  and  b  are integers, which of the following is not necessarily an integer?', NULL, '1', '2a - 5b', 'a^7', 'b^a', 'ab'),
(180, 'hardmath', '3601', 'What is the least number which on being divided by 5, 6, 8, 9, 12 leaves in each case a remainder 1 but when divided by 13 leaves no remainder?', NULL, '1', '2987', '3601', '3600', 'Null'),
(181, 'hardmath', 'x is always even.', 'If 7x + 6y = 420, x and y are natural numbers, then what can be said about x?', NULL, '1', 'x is always odd.', 'x is always even.', 'x is even only if y is odd.', 'x is odd if y is even.'),
(182, 'hardmath', '429', 'Look at this series: 8, 6, 9, 23, 87 , ... What number should come next?', NULL, '1', '128', '226', '324', '429'),
(183, 'hardmath', '3600 meters', 'Two boats on opposite banks of a river start moving towards each other. They first pass each other 1400 meters from one bank. They each continue to the opposite bank, immediately turn around and start back to the other bank. When they pass each other a second time, they are 600 meters from the other bank. We assume that each boat travels at a constant speed all along the journey. Find the width of the river?', NULL, '1', '3800 meters', '4000 meters', 'Null', '3600 meters'),
(184, 'hardmath', '124', 'If 200 is added to a positive integer I, the result is a square number. If 276 is added to to the same integer I, another square number is obtained. Find I.', NULL, '1', '123', '124', '125', 'Null');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
