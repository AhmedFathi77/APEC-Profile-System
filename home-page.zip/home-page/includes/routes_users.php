<?php
if (isset($_POST['r1'])&&isset($_POST['r2'])) {
	$r1 = addslashes($_POST['r1']);
	$r2 = addslashes($_POST['r2']);
	$profiles_dir = 'apec-profile';
	require_once '../../'.$profiles_dir.'/private/includes/config.php';
	if(!isset($_SESSION['user_id'])){/*header("location:..");exit();*/}
	$id = $_SESSION['user_id'];
	require_once 'db/connection.php';
	$sql = "INSERT INTO `routes_users`(`user_id`, `first`, `second`, `stage`) VALUES ('$id','$r1','$r2',1)";
	$stmt=$db->prepare($sql);
	$stmt->execute();
}