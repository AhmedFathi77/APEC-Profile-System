<?php
function hasFullTime($user_id,$minutes){ // if not started yet returns FRESH
										//if started less than x min return false
										//if started more than x min return true
										//if submitted x min return true
	require'db/connection.php';
	$sql="SELECT `started_at` , `status` FROM `pst_results` WHERE `user_id` = '$user_id'";
	date_default_timezone_set("Africa/Cairo");
	$stmt = $db->query($sql);
	if($stmt->rowCount()){ // not fresh
		$stmt = $stmt->fetchAll();
		if ($stmt[0]['status']==='submitted') {
			return true;
		}
		$started = $stmt[0]['started_at'];
		$period = ceil((time()-strtotime($started))/60);
		if ($period<$minutes) {
			return false;
		}
		else{
			return true;
		}
	}
	else{
		return "FRESH";
	}
}
?>