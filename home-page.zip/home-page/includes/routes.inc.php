<?php
require_once 'db/connection.php';
$sql = "SELECT * FROM `routes` WHERE 1";
$stmt=$db->query($sql);
if($stmt->rowCount()){
$stmt = $stmt->fetchAll();
}
foreach ($stmt as $route) {
?>


<li class="col-lg-4 col-sm-12 col-md-6  preference <?php echo strtolower($route['track']); ?>" id="<?php echo 'route-'.$route['id']; ?>">


    <div class="thumbnail" style="height:60vh ; ">

        <img src="http://apec-eg.com/apec-profile/job/img/<?php echo $route['img']; ?>" alt=""   style="width:240px;height:200px">

      <div class="caption" >
        <h3 style="font-size:20px"><?php echo $route['name']; ?></h3>
        <p style="">
        <?php echo $route['content']; ?>
    </p>
        <p><a href="#" class="btn btn-defult" role="button"  onclick="applying('<?php echo $route['name']; ?>','<?php echo $route['id']; ?>')" >APPLY NOW</a></p>
      </div>

   </div>


</li>

<?php
}