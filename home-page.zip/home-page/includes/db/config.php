<?php
		define("HOSTi","localhost");
		define("USERNAMEi","cl20-apec");
		define("PASSWORDi","APEC17db");
		define("DBNAMEi","cl20-apec");
?>