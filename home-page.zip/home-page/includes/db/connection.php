<?php 
// dbc : mysqli OOP ,, db: pdo ,, dbp
		require_once("config.php");
		$dbc=@new mysqli(HOSTi,USERNAMEi,PASSWORDi,DBNAMEi);
		if($dbc->connect_error){
			die("Connection Failed, ".$dbc->connect_error);
		}
		$dbc->set_charset("utf8"); 
		// Connection To DataBase .. 
		// I need To Create Setup In This Projects At The End .. So User Name And Password Will Be Change .. 
		try
		{
			$arabic=[PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"];
			$db = new PDO ('mysql:host=' . HOSTi . ';dbname=' . DBNAMEi,USERNAMEi,PASSWORDi,$arabic);
			$db -> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			exit;
		}
		// 3
		$dbp = mysqli_connect(HOSTi,USERNAMEi,PASSWORDi,DBNAMEi);
		mysqli_set_charset($dbp,"utf8");
?>