<?php
require_once 'db/connection.php';
require_once 'functions_list.php';

//Create a query to fetch all the questions
$easylogicfetch   ="SELECT * FROM questions where category='easylogic' ORDER BY RAND() Limit 3 ";
$easyiqfetch    = "SELECT * FROM questions where category='easyiq' ORDER BY RAND() Limit 3  ";
$easyEnglishfetch = "SELECT * FROM questions where category='easyenglish' ORDER BY RAND() Limit 3 ";
$easyMathfetch = "SELECT * FROM questions where category='easymath' ORDER BY RAND() Limit 3 ";

$mediumlogicfetch   ="SELECT * FROM questions where category='mediumlogic' ORDER BY RAND() Limit 4 ";
$mediumiqfetch    = "SELECT * FROM questions where category='mediumiq' ORDER BY RAND() Limit 4  ";
$mediumEnglishfetch = "SELECT * FROM questions where category='mediumenglish' ORDER BY RAND() Limit 4 ";
$mediumMathfetch = "SELECT * FROM questions where category='mediummath' ORDER BY RAND() Limit 4 ";

$hardlogicfetch   ="SELECT * FROM questions where category='hardlogic' ORDER BY RAND() Limit 3 ";
$hardiqfetch    = "SELECT * FROM questions where category='hardiq' ORDER BY RAND() Limit 3  ";
$hardEnglishfetch = "SELECT * FROM questions where category='hardenglish' ORDER BY RAND() Limit 3 ";
$hardMathfetch = "SELECT * FROM questions where category='hardmath' ORDER BY RAND() Limit 3 ";

//Run the query

$query_result1 = $dbc->query($easylogicfetch);
$query_result2 = $dbc->query($easyiqfetch);
$query_result3 = $dbc->query($easyEnglishfetch);
$query_result4 = $dbc->query($easyMathfetch);

$query_result5 = $dbc->query($mediumlogicfetch);
$query_result6 = $dbc->query($mediumiqfetch);
$query_result7 = $dbc->query($mediumEnglishfetch);
$query_result8 = $dbc->query($mediumMathfetch);

$query_result9 = $dbc->query($hardlogicfetch);
$query_result10 = $dbc->query($hardiqfetch);
$query_result11 = $dbc->query($hardEnglishfetch);
$query_result12 = $dbc->query($hardMathfetch);

//Count the number of returned items from the database
/**/
//$num_questions_returned = $query_result1->num_rows;

 
 
 
//if ($num_questions_returned < 1){
   // echo "There is no question in the database";
   // exit();
 // } /**/

//Create an array to hold all the returned questions
$iqArray = array();
$logicArray = array();
$englishArray = array();
$mathArray = array();

//Add all the questions from the result to the questions array
while ($row = $query_result1->fetch_assoc()){
    $logicArray[] = $row;
}
while ($row = $query_result5->fetch_assoc()){
    $logicArray[] = $row;
}
while ($row = $query_result9->fetch_assoc()){
    $logicArray[] = $row;
}
////////////////////////////////////////////
while ($row = $query_result2->fetch_assoc()){
    $iqArray[] = $row;
}
while ($row = $query_result6->fetch_assoc()){
    $iqArray[] = $row;
}
while ($row = $query_result10->fetch_assoc()){
    $iqArray[] = $row;
}
///////////////////////////////////////////
while ($row = $query_result3->fetch_assoc()){
    $englishArray[] = $row;
}
while ($row = $query_result7->fetch_assoc()){
    $englishArray[] = $row;
}
while ($row = $query_result11->fetch_assoc()){
    $englishArray[] = $row;
}
////////////////////////////////////////
while ($row = $query_result4->fetch_assoc()){
    $mathArray[] = $row;
}
while ($row = $query_result8->fetch_assoc()){
    $mathArray[] = $row;
}
while ($row = $query_result12->fetch_assoc()){
    $mathArray[] = $row;
}
////////////////////////////////////////
//Create an array of Correct answers

$iqcorrectAnswerArray = array();
foreach($iqArray as  $question){
    $iqcorrectAnswerArray[$question['id']] = $question['correct'];
}

$logiccorrectAnswerArray = array();
foreach($logicArray as  $question){
    $logiccorrectAnswerArray[$question['id']] = $question['correct'];
}

$englishcorrectAnswerArray = array();
foreach($englishArray as  $question){
    $englishcorrectAnswerArray[$question['id']] = $question['correct'];
}

$mathcorrectAnswerArray = array();
foreach($mathArray as  $question){
    $mathcorrectAnswerArray[$question['id']] = $question['correct'];
}


//Build the questions & phts array from query result

$iqimage = array();
$iqquestion = array();
$iqtype = array();
foreach($iqArray as $question) {
    $iqimage[$question['id']] = $question['image'];
    $iqquestion[$question['id']] = $question['question'];
    $iqtype[$question['id']] = $question['type'];

 }

$logicquestion = array();
$logicimage =array();
$logictype =array();

foreach($logicArray as $question) {

    $logicimage[$question['id']] = $question['image'];
    $logicquestion[$question['id']] = $question['question'];
    $logictype[$question['id']] = $question['type'];

}

$englishquestion = array();
$englishtype = array();
foreach($englishArray as $question) {
    
    $englishquestion[$question['id']] = $question['question'];
    $englishtype[$question['id']] = $question['type'];

 }
 $mathquestion = array();
$mathimage =array();
$mathtype =array();

foreach($mathArray as $question) {

    $mathimage[$question['id']] = $question['image'];
    $mathquestion[$question['id']] = $question['question'];
    $mathtype[$question['id']] = $question['type'];

}

//Build the choices array from query result
$iqchoices = array();
$lchoices = array();
$echoices = array();
$mchoices = array();

foreach ($iqArray as $row) {
    $iqchoices[$row['id']] = array($row['answer1'], $row['answer2'], $row['answer3'], $row['answer4']);
  }

foreach ($logicArray as $row) {
    $lchoices[$row['id']] = array($row['answer1'], $row['answer2'], $row['answer3'], $row['answer4']);
  }

foreach ($englishArray as $row) {
    $echoices[$row['id']] = array($row['answer1'], $row['answer2'], $row['answer3'], $row['answer4']);
  }
foreach ($mathArray as $row) {
    $mchoices[$row['id']] = array($row['answer1'], $row['answer2'], $row['answer3'], $row['answer4']);
}
?>