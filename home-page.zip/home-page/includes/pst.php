<div class="section-container-test test-page">	
	<section id="form " class="bg-light-gray">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12 ">
					<form name="quiz" id="quiz" action="includes/submittedProcess.php" method="POST">
					<input name="visited" type="hidden" value="">
					<ol>
					<!-- <h1 class="text-center">iq</h1><hr>
					START OF iq Questions -->
					<?php
						$iqquestion = shuffle_assoc($iqquestion);
						foreach($iqquestion as $id => $question) {
						$Ques=nl2br($question);
					?>
						<li class="form-group">
							<p style=" font-size:130%;"><?php echo($Ques); ?></p>
							<ol>
							<?php 
										
								$image = $iqimage[$id];
								if(!($image==null)){ ?>
								
							         <img src="imgs/pst/<?php echo($image);?>" class"img-responsive col-lg-12" align="center"/>
							  		 <br><br><br>
								<?php 
								}
									//Display multiple choices
									$iqrandomChoices = $iqchoices[$id];
									$type           = $iqtype[$id];
									if($type==1){ // 1 means randomize the answers 
									$iqrandomChoices = shuffle_assoc($iqrandomChoices);
									}
									foreach ($iqrandomChoices as $key => $values){
									if(!(is_null($values)||$values=="Null")){	
									?>
										<li>
										  <input type="radio" name="responseIQ[<?php echo($id); ?>]" id="<?php echo($id);?>" value="<?php echo(nl2br($values));?>">
										  <label for="question-<?php echo($id); ?>"><?php echo(nl2br($values));?></label>
										</li>
									<?php }} ?>
												</ol>
												</li>
										<?php } ?>	
										<!-- END OF IQ Questions -->
										
					<!-- class="text-center">Logic</h1><hr>
					 START OF Logic Questions -->
					<?php
							
						$logicquestion = shuffle_assoc($logicquestion);
						foreach($logicquestion as $id => $question) {
						$Ques=nl2br($question);
					?>
					<li class="form-group">
					  <p style=" font-size:130%;"><?php echo($Ques); ?></p>
						<ol>
							<?php 
										
								$image = $logicimage[$id];
								if(!($image==null)){ ?>
								
							         <img src="imgs/pst/<?php echo($image);?>" class"img-responsive col-lg-12" align="center"/>
							  		 <br><br><br>
						       <?php
								}
							   //Display multiple choices
										$type = $logictype[$id];
								        $lrandomChoices = $lchoices[$id];
										if($type==1){
											  $lrandomChoices = shuffle_assoc($lrandomChoices);
										}

								foreach ($lrandomChoices as $key => $values){
									if(!(is_null($values)||$values=="Null")){			?>
								<li>
								  <input type="radio" name="responseLogic[<?php echo($id);?>]" id="<?php echo($id);?>" value="<?php echo(nl2br($values));?>">
								  <label for="question-<?php echo($id); ?>"><?php echo(nl2br($values));?></label>
								</li>
								<?php }} ?>
								</ol>
								</li>
							<?php } ?>	
							<!-- END OF Logic Questions -->


							<!-- class="text-center">Logic</h1><hr>
					 START OF Math Questions -->
					<?php
							
						$mathquestion = shuffle_assoc($mathquestion);
						foreach($mathquestion as $id => $question) {
						$Ques=nl2br($question);
					?>
					<li class="form-group">
					  <p style=" font-size:130%;"><?php echo($Ques); ?></p>
						<ol>
							<?php 
										
								$image = $mathimage[$id];
								if(!($image==null)){ ?>
								
							         <img src="imgs/pst/<?php echo($image);?>" class"img-responsive col-lg-12" align="center"/>
							  		 <br><br><br>
						       <?php
								}
							   //Display multiple choices
										$type = $mathtype[$id];
								        $mrandomChoices = $mchoices[$id];
										if($type==1){
											  $mrandomChoices = shuffle_assoc($mrandomChoices);
										}

								foreach ($mrandomChoices as $key => $values){
									if(!(is_null($values)||$values=="Null")){			?>
								<li>
								  <input type="radio" name="responseMath[<?php echo($id);?>]" id="<?php echo($id);?>" value="<?php echo(nl2br($values));?>">
								  <label for="question-<?php echo($id); ?>"><?php echo(nl2br($values));?></label>
								</li>
								<?php }} ?>
								</ol>
								</li>
							<?php } ?>	
							<!-- END OF Math Questions -->
												
			<!--class="text-center">English</h1><hr>
												
			 START OF English Questions -->
			<?php
				$englishquestion = shuffle_assoc($englishquestion);
				foreach($englishquestion as $id => $question) {
				$Ques=nl2br($question); //phpfunction to fix text style
			?>
																		
				<li class="form-group">
				  <p style=" font-size:130%;"><?php echo($Ques); ?></?php></p>
					<ol>
						<?php 
							//Display multiple choices
							$erandomChoices = $echoices[$id];
							$type=$englishtype[$id];
							if($type==1){
								$erandomChoices = shuffle_assoc($erandomChoices);
							}
							foreach ($erandomChoices as $key => $values){
								if(!(is_null($values)||$values=="Null")){	
							?>
								<li>
								  <input type="radio" name="responseEnglish[<?php echo($id);?>]" id="<?php echo($id);?>" value="<?php echo(nl2br($values));?>">
								  <label for="question-<?php echo($id); ?>"><?php echo(nl2br($values));?></label>
								</li>
							<?php }} ?>
					</ol>
				</li>
			<?php } ?>	
			<!-- END OF English Questions -->
					</ol>	
						<div align="center" ><input type="submit" name="submitquiz" class="btn text-center"  value="Submit Test" /></div>
					</form>
				</div>
			</div>
		</div>
	</section>
</div>