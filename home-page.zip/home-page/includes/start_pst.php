<?php
require_once"db/connection.php";
require_once"quiz.php";
if(isset($_POST['id'])){
	$id=addslashes($_POST['id']);
	try{
			//2-inserting user status
			$sql="INSERT INTO `pst_results`(`user_id`,`status`) VALUES ('$id','tested')";
			$stmt=$db->prepare($sql);
			$stmt->execute();
			require_once"pst.php";
		}
	catch(PDOException $e){
		echo $sql . "<br>" . $e->getMessage();
	}
}
?>