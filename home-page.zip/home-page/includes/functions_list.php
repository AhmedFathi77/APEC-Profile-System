<?php

function add_slashes($string){
    if(get_magic_quotes_gpc() == 1){
        return $string;
    } else {
        return addslashes(($string));
    }
}

function redirect_to($new_url){
    header("Location: " . $new_url);
    exit;

}

function shuffle_assoc($list) {
    if (!is_array($list)) return $list;

    $keys = array_keys($list);
    shuffle($keys);
    $random = array();
    foreach ($keys as $key) {
        $random[$key] = $list[$key];
    }
    return $random;
}
function isTestedUser($id,$db)
{
    $sql="SELECT * FROM `tested_users` WHERE `user_id`='$id'";
    $stmt=$db->query($sql);
    $exist='Null';
    foreach ($stmt as $tested) {
        if($tested['user_id']==$id){
            $exist=1;
        }
    }
    return $exist;
}
function isPstPassed($id ,$scoreTarget , $db)
{
    // already checked he is tested..
    $sql="SELECT `score` FROM `tested_users` WHERE `user_id`='$id'";
    $stmt=$db->query($sql);
    foreach ($stmt as $tested) {
        if ($tested['score']>=$scoreTarget) {
            return 1;
        }
        else{
            return 0;
        }
    }
}
// testing :
require_once 'db/connection.php';
//echo isPstPassed(3,0,$db);