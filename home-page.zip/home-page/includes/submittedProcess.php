<?php
$profiles_dir = 'apec-profile';
require_once '../../'.$profiles_dir.'/private/includes/config.php';
error_reporting(0);
ini_set('display_errors', 0);
require_once('db/connection.php');
require_once('functions_list.php');
require_once('quiz.php');

$user_id = $_SESSION['user_id'];
$rightAnswerLogic = 0;
$rightAnswerIQ = 0;
$rightAnswerEnglish = 0;
$rightAnswerMath = 0;

$answersArray = array();  //correct answers

$result = $dbc->query("select id , correct from questions");
if(!$result) {die($connection->error);}

while ($row = $result->fetch_assoc()) {
	$answersArray[$row["id"]] = $row["correct"];
}

if ($_SERVER["REQUEST_METHOD"] == "POST"){
	foreach($_POST['responseIQ'] as $key => $value){
      if($answersArray[$key] == $value){
           $rightAnswerIQ++;
       }
	} 

	foreach($_POST['responseLogic'] as $key => $value){

      if($answersArray[$key/*id of qsn*/] == $value){
          $rightAnswerLogic++;
      }
	}
	foreach($_POST['responseEnglish'] as $key => $value){

      if($answersArray[$key] == $value){
          $rightAnswerEnglish++;
      }
	}  
	foreach($_POST['responseMath'] as $key => $value){

      if($answersArray[$key] == $value){
          $rightAnswerMath++;
      }
	}  
}

$rightAnswer =0 ; //All
$rightAnswer = $rightAnswerIQ + $rightAnswerLogic + $rightAnswerEnglish + $rightAnswerMath;
/*
 if($rigthAnswer >= 15){
	 $mark=1;
	 $query = "update visits_2016 set score = {$rightAnswer}, math = {$rightAnswerIQ}, logic = {$rightAnswerLogic}, english = {$rightAnswerEnglish} ,mark={$mark} where mobile = {$mobile} ";

		$result = $dbc->query($query);
	  $_SESSION['login_user']=$mobile; // Initializing Session
      header("location: date.php"); // Redirecting To Other Page
 }else{
	 $mark=1;
	 $query = "update visits_2016 set score = {$rightAnswer}, math = {$rightAnswerIQ}, logic = {$rightAnswerLogic}, english = {$rightAnswerEnglish} ,mark={$mark} where mobile = {$mobile} ";
	 $result = $dbc->query($query);
	 $error"sorry you didn't pass the online test "
 }
*/
 //$mark=4; // for internals 
  $flag = "submitted"; // for externals 
   $query = "UPDATE `pst_results` set `score` = '$rightAnswer', `math` = '$rightAnswerMath', `logic` = '$rightAnswerLogic', `english` = '$rightAnswerEnglish', `iq` = '$rightAnswerIQ', `status`='$flag' where `user_id` = '$user_id'";
   $result = $dbc->query($query);
 //echo $rightAnswer.$rightAnswerMath.$rightAnswerLogic.$rightAnswerEnglish.$rightAnswerIQ.$flag.$user_id;
 header("location: ../");
?>