<?php
require_once 'db/connection.php';
$profiles_dir = 'apec-profile';
	require_once '../../'.$profiles_dir.'/private/includes/config.php';
if(!isset($_SESSION['user_id'])){/*header("location:..");exit();*/}
$id = $_SESSION['user_id'];
$sql = "SELECT `stage` FROM `routes_users` WHERE user_id ='$id'";
$stmt=$db->query($sql);
if($stmt->rowCount()){
$stmt = $stmt->fetchAll();
$s = $stmt[0]['stage'];
echo $s;
}
else{
	echo 0;
}