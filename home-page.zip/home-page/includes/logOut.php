<?php
$profiles_dir = 'apec-profile';
require_once '../../'.$profiles_dir.'/private/includes/config.php';
if (isset($_SESSION['user_id'])) {
	unset($_SESSION['user_id']);
	$_SESSION = [];
	session_destroy();
	if ( isset( $_COOKIE[session_name()] ) ){
		//echo "cookie";
		setcookie( session_name(),"",0);
	}
}
header("Location: ../");
exit();

?>