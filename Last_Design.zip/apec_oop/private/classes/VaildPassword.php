<?php



	trait VaildPassword
	{
		protected function VailedPassword($pwd)
		{
			if(preg_match('/^(\w*(?=\w*\d)(?=\w*[a-z])(?=\w*[A-Z])\w*){6,}$/', $pwd) && strlen($pwd) >= 5) // Must Be Contain One Upper Case letter And One Lower Case letter And One Number
			{
				return $pwd;
			}

			return false;
		}


	}