<?php




class Register 
{
	// Use Vaildation Of Phone Number (Trait) ..

	use VaildPhoneNumber;
	use VaildPassword;


	protected $firstName;
	protected $lastName;
	protected $email;
	protected $pwd;
	protected $country;
	protected $Crud;
	protected $cleardata;
	protected $db;
	public $activeCode;
	protected $errorMsg = array();


	function __construct(DataBase $db_instance, Crud $crud_instance , ClearData $clean_instance)
	{
		$this->db = $db_instance;
		$this->Crud = $crud_instance;
		$this->cleardata = $clean_instance;

	}

	public function setFirstName ($fN)
	{
		$this->firstName = $fN;
		$this->firstName = $this->cleardata->clearedData($this->firstName ,'string');
		if(is_array($this->firstName)) $this->errorMsg[] = $this->firstName;
		return $this;
	}

	public function setlastName ($lN)
	{
		$this->lastName = $lN;
		$this->lastName = $this->cleardata->clearedData($this->lastName ,'string');
		if(is_array($this->lastName)) $this->errorMsg[] = $this->lastName;
		return $this;
	}

	public function setPwd ($pwd)
	{
		$this->pwd = $pwd;
		$this->pwd = $this->VailedPassword($pwd);
		if(is_string($this->pwd)) $this->pwd = password_hash($this->pwd , PASSWORD_BCRYPT);
		else $this->errorMsg['Invaild_Password'] = 'Example Of Correct Password : Zmx1b  One UpperCase Chars - Three Lower Case - One Number ';
		return $this;
	}

	public function setcountry($country)
	{
		$this->country = $country;
		return $this;
	}

	public function setEmail ($email)
	{
		$this->email = $email;
		$this->email = $this->cleardata->clearedData($this->email ,'email');
		if(is_array($this->email)) $this->errorMsg[] = $this->email;
		return $this;
	}
	public function addUser(Sms $messageSystem)
	{
		if($this->userFoundOrNot() == false && empty($this->errorMsg)) // This Mean User Not Found ..
		{
			// 0- Get  Code ..
			$code_to_send =  $this->activeCode();
			// 1- Send Code To His/Her Mobile ..
			$sender = $messageSystem->sendMessages($code_to_send , $this->phone);
			if(!$sender) throw new Exception("Sorry We Have A Problem Please Try Again Latter");
			
			// 2-Add The User In Non-Active Status 
			$newUser = $this->Crud->setTableName('users')->setColumnName(array('firstName','lastName','pwd','country','image','phone'))->setData(array(1=>$this->firstName,$this->lastName,$this->pwd,$this->country,null,$this->phone))->insert($this->db);
			if($newUser == false) throw new Exception("Sorry About That Please Try Again Later ");
			

			
			// 3- Redurect User To Verfiy Code ..
			
			return $code_to_send;

		}elseif (!empty($this->errorMsg)) 
		{
			// Return errorMsg ..
			return $this->errorMsg;
		}
		throw new Exception("Error !");
		
	} 
	// DataBase $db_instance , array $where_clause = null , array $specific_columns = array("all" => '*')
	protected function  userFoundOrNot() // This For Check If User Phone Found In DataBase ..
	{
		$this->phone = $this->regexRegisterPhone($this->phone);
		if($this->phone != false)
		{
			         		$userFoundOrNot = $this->Crud->setTableName('users')->selectData($this->db , array('phone' , "\"$this->phone\"") , array('phone')); 
			         		
							if($userFoundOrNot == false)
							{
								return false; // This Mean User Not Found ..

							}else
							{
								$this->errorMsg['user_register'] = 'This Phone Number Found If You  The Owner Please Login In If You Have A Problem You Can Contact Us At ' . CONTACT_EMAIL;
							}
		}else
		{
			$this->errorMsg['invaild_phone'] = 'Invailed Phone Number Example :- 01234567890';
				
		}

				return $this->errorMsg;
	}

	protected function activeCode()
	{
		 $this->activeCode = rand(10000 , 20000);
		 return $this->activeCode;


	}





}