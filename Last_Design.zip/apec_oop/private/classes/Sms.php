<?php
	
	class Sms
	{
		protected $userNumber;
		protected $message;
		protected $twilio_number;
		protected $client;
		protected $msgSend = false;
		protected $errorMsg = array();

		function __construct($twilio_number  , Twilio\Rest\Client  $client)
		{
			$this->client = $client;
			$this->twilio_number = $twilio_number;
		}

		public function sendMessages($message , $phone) // Message And Phone Number Must Be Clear Data!
		{
				$this->userNumber = $phone;
				$this->message = $message;
				$msg = $this->client->account->messages->create($this->userNumber , array(  // Step 6: Change the 'From' number below to be a valid Twilio number 
                // that you've purchased
                'from' => $this->twilio_number, 
                
                // the sms body
                'body' => $this->message));
					
				if($msg->status == 'queued')
				{
					return true;

				}

			return false;
		}

		// This Function Must Be Felixable For Subject And More Property Add To It Crew 18 ..
		public function sendMailer($message , $mail)
		{
			$this->message = $message;
			// string $to , string $subject , string $message 
			$sendMail = mail($mail , 'Welcome To Apec' , $message);
			if($sendMail){return true;}else{return false;}

		}

		



	}