<?php


class Login
{
	use VaildPassword;
	protected $email;
	protected $password;
	protected $db_instance;
	protected $crud;
	protected $cleardata;
	protected $errorMsg = array();


	function __construct(DataBase $instance_db , Crud $instance , ClearData $clear_instance)
	{
		$this->crud = $instance;
		$this->cleardata = $clear_instance;
		$this->db_instance = $instance_db;
	}

	public function setEmail ($email)
	{
		$this->email = $email;
		$this->email = $this->cleardata->clearedData($this->email ,'email');
		if(is_array($this->email)) $this->errorMsg[] = $this->email;
		return $this;
	}

	public function setPassword($pwd)
	{
		$this->password = $pwd;
		return $this;
	}

	public function  checkUserLogin ()
	{
		if(array_key_exists('user_id', $this->userInfoRightOr()) && empty($this->errorMsg))
		{
			return array('user_id' => $this->userInfoRightOr()['user_id'] , 'first_login'=>$this->userInfoRightOr()['first_login']);
		}else if(!empty($this->errorMsg))
		{
			return $this->errorMsg;
		}

		throw new Exception("Sorry Error Found In Our System Please Try Again Latter Or Contact Us At " . CONTACT_EMAIL);
		

	}


	// DataBase $db_instance , array $where_clause = null , array $specific_columns = array("all" => '*'
	protected function userInfoRightOr() // If True User Must Be Login In .. False Get A Message ..
	{
		$checkUser = $this->crud->setTableName('users')->selectData($this->db_instance , array('email' , "\"$this->email\""), array('email' , 'pwd' , 'id' , 'first_login'));
		if($checkUser) // This Mean The Email Found In DataBase ..
		{
			//var_dump($checkUser); Return Array[0] email -- Array[1] pwd ..
			$pwd_right = (password_verify( $this->password , $checkUser[1])) ? true : false;
			if($pwd_right)  return array( 'user_id'=>$checkUser[2] ,'first_login' => $checkUser[3]);
			else $this->errorMsg['Wrong_pwd'] = 'Your Email Address Or PassWord Not Correct ..';
		}else
		{
			$this->errorMsg['email_or_pwd'] = 'Email Not Found Please Register Now To Connect To Apec ..';

		}

		return $this->errorMsg;
	}

}