<?php

	
	/* Methods */
		//	abstract public bool close ( void );
		//	abstract public bool destroy ( string $session_id ); DataBase $db_instance , Crud $get_data)
		//	abstract public bool gc ( int $maxlifetime );
		//	abstract public bool open ( string $save_path , string $session_name );
		//	abstract public string read ( string $session_id );
		//	abstract public bool write ( string $session_id , string $session_data );
	class SessionHandlerApec implements	SessionHandlerInterface 
	{
		private static $_dbconnection;
		private static $_crudObject;
	//	private $sessionName = 'apec';
		private static $_instance = null;
		private $db_open;

		private function __construct()
		{

		}

		public static function getInstance(DataBase $db_instance , Crud $get_data) {
        if(self::$_instance == null ) 
        {
                
                self::$_dbconnection = $db_instance;
                self::$_crudObject = $get_data;
                self::$_instance = new SessionHandlerApec();
                session_set_save_handler(self::$_instance , true);
               
        }
        	 session_register_shutdown();
             session_start();
		    return self::$_instance;
        }


		public function  read ( $session_id)
		{
			
			//  Parameter  of SelectData (DataBase $db_instance , array $where_clause = null , array $specific_columns = array("all" => '*')) 
			$dataSelected = self::$_crudObject->setTableName('apecsession')->selectData(self::$_dbconnection , array('id' , "\"$session_id\"") , array("sdata")); 

			if(count($dataSelected) == 1)
			{
				  list($data) = $dataSelected;
				  return (string) $data;

			}else
			{
				return '';
			}


			throw new Exception("Sorry There Is A problem Please Send Message To Admin At " . CONTACT_EMAIL);
		}

		public function write( $session_id ,  $session_data)
		{
			$replace_statement = sprintf(" REPLACE INTO %s  ( %s, %s) VALUES (%s , %s) " , 'apecsession' , 'id',  'sdata' , '?', '?') ;

			$replace = $this->db_open->prepare($replace_statement);
			$replace ->bindparam(1 , $session_id , PDO::PARAM_STR);
			
			
			$replace ->bindparam(2 , $session_data , PDO::PARAM_STR);
			
			$replace ->execute();
			if($replace->rowcount() >= 1)
			{
				return true;
			}
			return false;
		}
		// DataBase $db_instance , array $where_clause .. 
		public function destroy ( $session_id )
		{


			$deleteData = self::$_crudObject->setTableName('apecsession')->deleteData(self::$_dbconnection , array('id',"\"$session_id\""));
			
			if($deleteData)
			{
				$_SESSION = array();
				return true;
			}
			return true;
		}

		public function open (  $save_path ,  $session_name )
		{
			$this->db_open = self::$_dbconnection->dataBaseConnection();
			return true;
		}

		public function gc ($maxlifetime)
		{
			$gcStatement =sprintf("  DELETE FROM %s WHERE DATE_ADD(%s , INTERVAL %d SECOND) < NOW() " , 'apecsession' , 'lastaccess', '?'); 

			$deleteQuery = $this->db_open->prepare($gcStatement);
			$deleteQuery ->bindparam(1 , $maxlifetime , PDO::PARAM_INT);
			$deleteQuery  ->execute();
			return true;
		}

		public function close ()
		{
			$this->db_open = null;
			return true;
		}


		

		


	}