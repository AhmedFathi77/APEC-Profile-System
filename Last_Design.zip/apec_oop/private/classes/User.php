<?php

class User
{



	protected $id;
	protected $firstName;


	protected $lastName;
	protected $pwd;
	protected $first_login;
	protected $email;
	protected $active;

	private   $phone;
	private   $country;
	private   $errorMsg = array();

	private   $dataUserAdd = array();
	private   $dataTypeUserAdd = array();

	private   $userExtraData = array('skill','course','trainning','activity'); // Extra Data Of User Put In This Array ..
	private   $userEssData = array('about','education'); // Essentail Data Of User Put In This Array ..

	private   $db_ins;
	private   $crud;



	private   $clear;
	private   $sp;

	public function __construct(DataBase $dbh , Crud $crud_instance , ClearData $clear_datainstance , StoredProcedure $sop)
	{
		$this->db_ins = $dbh;
		$this->crud   = $crud_instance;
		$this->clear  = $clear_datainstance;
		$this->sp     = $sop;

	}

	public function getId()
	{
		return $this->id;
	}

	public function getPhone()
	{
		return $this->phone;
	}

	public function setId(int $id)
	{
		$this->id = $id ;
		return $this;

	}

	public function getfirstLogin()
	{
		return $this->first_login;

	}

	public function getUserName()
	{
		return ucwords($this->firstName . ' ' . $this->lastName); 
	}

	public function getCountry()
	{
		return $this->country;
	}

	public function canEdit(int $id)
	{
		return ($this->id == $id) ? true : false ;

	}



	// This Function Must Return Into Crud And Be More Felxaible (Dynamic) ..
	public function getUserData(int $id)
	{
		$userData = sprintf(" Select * from %s WHERE %s = %s " , 'users' , 'id' , '?' );
		$db = $this->db_ins->dataBaseConnection();
		$userData = $db->prepare($userData);
		$userData->bindparam( 1 , $id , PDO::PARAM_INT);
		$userData->setFetchMode(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE , 'User' , array($this->db_ins,$this->crud,$this->clear,$this->sp));
		$userData->execute();
		$userInfo = $userData->fetch();

		return  $userInfo;


	}

	// About Stored Procedure => id_user int , bio_n text(150) , lives_in_n varchar(30) .. 
	/* Education => id_user int, uni_n varchar(50) , faculty_n varchar(50), department_n varchar(30) , 
year_n varchar(10) , grade_n varchar(20) , is_garduated_n bool */
	public function setData(array $data , array $type) // [ array( id_user , bio , lives_in) , 'education'=> array()]
	{
		//0. Get The Data As Array .. 
		$this->dataTypeUserAdd = $type;
		$this->dataUserAdd = $data;
		return $this;
		
		//2. If Data Has Error Put It In Error Msg .. And Return Error Msg .. Done 
		//3. All Ok Put Data With Help Of Stored Procedure .. Return  True If Success .. False If Not ..
	}
	// This Function Must Transfer Into ClearData ..
	// Need Refactor Print Alot Of Message I Solved It With array_unique() But Need More Logic 14/02/2017
	/*-- Updated 
		this function updated Now Return Unique Message To User 17/02/2017
	*/
	public function filterDataAsArray()
	{
		//1. Filter Each Item In Array ..
		$filterArrayData = array_map(array($this , 'useFilter') ,  $this->dataUserAdd , $this->dataTypeUserAdd);
		$dataOrg = $this->organizeData($filterArrayData);
		
		if($dataOrg && !is_array($dataOrg))
		{
			return true;

		}		
		return $dataOrg;

	}

		// Add User Data Into DataBase ..
	
	// This Function Need Some Logic And Must Be Private .. 
	// This Function For All Kind Of Data .. (Education - About (Replace) , Skill - activity - trainning - Courses (Insert))
	public function userDataToDataBase(array $data , string $type)
	{
		$Essentail  = (in_array($type, $this->userEssData)) ? true : false;
		$Extra  = (in_array($type, $this->userExtraData)) ? true : false;
		if(!$Essentail && !$Extra) {throw new Exception("Not Found This Data .."); }
		else 
		{
			if($Essentail) // This Mean About And Education .. Of User 
			{
				//0. Connect To Stored Procedure .. int $user_id ,  array $data , string $typeOfData
				$addUserEss = $this->sp->dataReplace($this->id , $data , $type);
				if($addUserEss)  return true;
				else throw new Exception("Error Processing Request .. Please Try Again Latter ");
			}

			if($Extra)
			{
				//1. Add User Data To Data Base Return True if Ok False .. If Not 
				// insertData(int $user_id , array $data_inserted, string $typeOfData) .. 
				$addUserExtra = $this->sp->insertData($this->id , $data , $type);
				if($addUserExtra) return true;
				else throw new Exception("Error Processing Request .. Please Try Again Latter ");
			}
		}
	}

	public function deleteUserData(int $dataId , string $type)
	{
		$deleteData = $this->sp->deleteData($dataId , $type);
		return $deleteData; // True If Suc .. Or False If Not ..

	}


	// This Function Need More Dynamic To Check All Error On Line 92
	private function organizeData (array $dataFilter)
	{
		 foreach ($dataFilter as $k => $val) 
				  {

				  		if(is_array($val))
						  {

						  		$this->errorMsg[] = $val;
						  }
				  }
				
		 if(empty($this->errorMsg))
			{
				  	return true; 
			}else
			{
				return $this->errorMsg;
			}
		throw new Exception("Error Please Contact The Admin At " . CONTACT_EMAIL . ' To Solve This Problem .. ');
		
	}

	// This Function Must Transfer Into ClearData ..
	private function useFilter($data , $type)
	{
		return $this->clear->ClearedData($data , $type);

	}




	






}