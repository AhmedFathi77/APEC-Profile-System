<?php 
	

	// Define Some Data ..	
	define("BASE_URI" ,"C:/wamp64/www/apec_oop/");
	define("BASE_URL" , "http://localhost/apec_oop/");


	// DataBase Config .. 
	define("HOST","localhost");
	define("D_Name","apec");
	define("U_Pass","");
    define("D_UserName","root");		





	//  Some Setting .. 
	ini_set("error_log", __DIR__ . "/error.log");


	
	
	 // Auto Load Classes ..
	spl_autoload_register(function($class_name){

		require BASE_URI . "private/classes/" . $class_name . '.php';
	});

	// Take Instance From DataBase And Instance From Crud Classess .. 
	$db_instance = DataBase::getInstance();
	$crud_instance = new Crud();
	$sp =	new StoredProcedure($db_instance);
	
		
	 // Intialize Session

     $session_open = SessionHandlerApec::getInstance($db_instance , $crud_instance);
     // Delete Gc Session ..
     $session_open->gc(1440 * 4); 
			










	

    // Twilio Information (Sms Service) ...
	$TwilioService  =array (
	"account_id" => 'AC4018de18ffdabff5e602e5d6bb89ef97',
	"auth_token" => 'dbd351edf2b7338df316faa7ba82157f',
	"twilio_number"=> '+16092514122'
	);


    require (BASE_URI . 'private/vendor/autoload.php'); // Inside ..
    // Use Twillio NameSpace..    
	use Twilio\Rest\Client; // Inside ..  
	$client = new Client($TwilioService['account_id'] , $TwilioService['auth_token']);

   




	



	

	// This Mail Will Use To Send Any Error To It In Message .. 
	define("CONTACT_EMAIL" , "IT@APEC-eg.com");



	



	function error_handler($e_number , $e_message , $e_file , $e_line , $e_vars)
	{
		$on = false;
		$Message = "There Is An Error On File " . $e_file . " <br />";
		$Message .= "No. -> $e_number At Line $e_line";

		if($on)
		{
			// Log It
			

			if($e_file != E_NOTICE)
			{
					// i Must Here Use Jquery And Some Thing Like That 

					echo "<h1>Sorry .. </h1>";
			}

			error_log($Message);

		}else
		{
			echo $Message;
		}

			return true;
	}
	//set_error_handler("error_handler");


	// Set Exception Handler 

	function my_exception_handler($m_Exception)
	{
			$on = false;

			if($on)
			{
				error_log($m_Exception);

			}else
			{
				echo $m_Exception->getMessage();
			}
		return true;	
	}

	set_exception_handler("my_exception_handler");

	
	// Use Only To Resirct Access To Pages .. 
	function redirectOutSide($location = null , $checkUser = 'user_id')
	{
		if(!isset($_SESSION["$checkUser"]) || empty($_SESSION["$checkUser"]))
		{
			$url = BASE_URL . "public/$location";
			header("Location:$url");
			exit();
		}

		return true;

	}


	function redirectInside($location = null , $checkUser = 'user_id')
	{
		if(isset($_SESSION["$checkUser"]) && !empty($_SESSION["$checkUser"]))
		{
			$url = BASE_URL . "public/$location";
			header("Location:$url");
			exit();
		}

		return true;


	}

	require(BASE_URI . "private/includes/responseMsg.inc.php");

