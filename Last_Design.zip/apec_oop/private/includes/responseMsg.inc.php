<?php


	/*
	* Website Response Messages .. Need More Dynamic ..
	* <script>swal("Here's a message!");</script>
	*/

	function responseMsg(array $message , $type)
	{
			$msg = implode('<br>' , $message);
		switch ($type) {
				case 'basic':
					return '<script>swal(' . '"' . $msg . '"' . ');</script>';
				
				case 'success':
					return '<script>swal("Done!",'. '"' . $msg . '"' . ',"success");</script>';
				
				case 'delete':
					return '<script>swal({   
							    title: "Are you sure?",   
							    text: ' . '"' . $msg . '"' . ',   
							    type: "warning",   
							    showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, delete it!" });</script>';
				
				case 'error':
					return '<script>swal("Oops...",' . '"' . $msg . '"' .  ', "error");</script>';
				
			    default:
						return array('No Meesage For This Case' , false);
				
		}

	}