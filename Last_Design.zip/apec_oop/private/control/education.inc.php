<?php

	
		if(isset($_POST['education']))
		{
			$eduDataToUpdate = array('uni_n'=>$_POST['uni'] , 'faculty_n'=>$_POST['faculty'] , 'year_n'=>$_POST['year'] , 'department_n'=>$_POST['department'] , 'grade_n'=>$_POST['grade'] ,  'is_garduated_n'=>1);
			$user->setData($eduDataToUpdate , array(1=>'string' , 'string' , 'string' , 'string' , 'string' , 'int'));
			$filter = $user->filterDataAsArray();
			$user->setId(intval($_SESSION['user_id'])); 
			if(!is_array($filter) && $filter) {$eduData = $user->userDataToDataBase($eduDataToUpdate , 'education');
				if($eduData)  $success =  responseMsg(array('You Update Your Education Information'), 'success');
				else $errorMsg['bad_response'] =  "Sorry Error Happen Please Try Again Latter!";}
			else
			{
				$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}

				$errorMsg = responseMsg($msg , 'basic');
				
			}




		}

	