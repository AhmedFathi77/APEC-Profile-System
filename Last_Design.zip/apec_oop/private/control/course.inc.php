<?php

	if(isset($_POST['user_course']))
	{
		    $courseData = array('cert'=>$_POST['certi'] , 'c_from_a'=>$_POST['course_from'] , 'year_n'=>$_POST['course_year'] , 'month_n'=>$_POST['month_course']);
			$user->setData($courseData , array(1=>'string','string','int','string'));
			$filter = $user->filterDataAsArray();
			$user->setId(intval($_SESSION['user_id'])); 
			if(!is_array($filter) && $filter) {$cData = $user->userDataToDataBase($courseData , 'course');
				if($cData) $success =  responseMsg(array('You Add New Course') , 'success');
				else $errorMsg['bad_response'] =  "Sorry Error Happen Please Try Again Latter!";}
			else
			{
				$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}

				$errorMsg = responseMsg($msg , 'basic');
				
			}

	}


	if(isset($_POST['delete_course_id']))
	{
		$activityDataDelete = $clear->clearedData($_POST['delete_course_id'],'int');
		if(!is_array($activityDataDelete)) 
		{
			$delete = $user->deleteUserData($_POST['delete_course_id'] , 'course');
			if($delete) $success = responseMsg(array('You Deleted Course!') , 'success');
			else  $errorMsg = responseMsg(array('Sorry Error Happen Please Try Again Latter!') , 'error');

		//$deleteConfirm = responseMsg( array(' You Want To Delete This Skill ?'), 'delete');
	    }else
	    {
	    		$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}
				$errorMsg = responseMsg($msg , 'basic');	
			
	    }

	}