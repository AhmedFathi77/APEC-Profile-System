<?php


	if(isset($_POST['user_train']))
	{
		    $trainData = array('cert'=>$_POST['train_name'] , 'decs_n'=>$_POST['train_desc'] , 'year_n'=>$_POST['t_year']);
			$user->setData($trainData , array(1=>'string','string','int'));
			$filter = $user->filterDataAsArray();
			$user->setId(intval($_SESSION['user_id'])); 
			if(!is_array($filter) && $filter) {$train = $user->userDataToDataBase($trainData , 'trainning');
				if($train) $success =  responseMsg(array('You Add New Trainning') , 'success');
				else $errorMsg['bad_response'] =  "Sorry Error Happen Please Try Again Latter!";}
			else
			{
				$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}

				$errorMsg = responseMsg($msg , 'basic');
				
			}

	}



	if(isset($_POST['delete_trainning_id']))
	{
		$trainDelete = $clear->clearedData($_POST['delete_trainning_id'],'int');
		if(!is_array($trainDelete)) 
		{
			$delete = $user->deleteUserData($_POST['delete_trainning_id'] , 'trainning');
			if($delete) $success = responseMsg(array('You Deleted Your Trainning Data!') , 'success');
			else  $errorMsg = responseMsg(array('Sorry Error Happen Please Try Again Latter!') , 'error');

		//$deleteConfirm = responseMsg( array(' You Want To Delete This Skill ?'), 'delete');
	    }else
	    {
	    		$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}
				$errorMsg = responseMsg($msg , 'basic');	
			
	    } 
	}