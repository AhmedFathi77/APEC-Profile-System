<?php

	
	if(isset($_POST['about']))
	{
			$phone = '';
			if(isset($_POST['phone']) && !empty($_POST['phone']))
			{
				$vaildedNumer = (!$clear->regexRegisterPhone($_POST['phone'])) ? false :  true;
				if($vaildedNumer) $phone = $_POST['phone']; 
				else $errorMsg['wrong_phone'] = 'This Phone Number Not Correct!';	

			}


			$userArrayAbout = array('lives_in_n'=>$_POST['lives_in']  , 'bio_n' =>$_POST['bio'] , $phone ,  $_POST['department'] , $_POST['uni'] );
			$aboutSlice = array_slice($userArrayAbout, 0 , 2);
		


			$user->setData($userArrayAbout , array_fill(1, 5, 'string'));
			$filter = $user->filterDataAsArray();
			$user->setId(intval($_SESSION['user_id'])); 
			if(!is_array($filter) && $filter) {
				$aboutData = $user->userDataToDataBase($aboutSlice , 'about');

				$edu = $crud2->setTableName('education')->setColumnName(array('department' , 'uni'))->setData(array($_POST['department'] , $_POST['uni']))->update($db_instance , array('e_data' , intval($_SESSION['user_id'])));
				$addPhone = $crud2->setTableName('users')->setColumnName(array('phone'))->setData(array($phone))->update($db_instance , array('id' , intval($_SESSION['user_id'])));
				// Logic MistKE iN This Check .. 
				if(is_bool($aboutData) && is_bool($edu) && is_bool($addPhone)) $success =  responseMsg(array('You Update Your About Information') , 'success');
				else $errorMsg = responseMsg(array('Sorry Error Happen Please Try Again Latter Contact Us At'  . CONTACT_EMAIL), 'error');
			}
			else
			{	
				$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}

				$errorMsg = responseMsg($msg , 'basic');
			}

	}