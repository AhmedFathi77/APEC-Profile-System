<?PHP


	if(isset($_POST['activity_add']))
	{
		    $activityAdd = array('position_n'=>$_POST['position'] ,'activity_n'=> $_POST['activity_name']  , 'year_n'=>$_POST['activtiy_year'] ,'job_des_n'=> $_POST['description']);
			$user->setData($activityAdd , array(1=>'string','string','int','string'));
			$filter = $user->filterDataAsArray();
			$user->setId(intval($_SESSION['user_id'])); 
			if(!is_array($filter) && $filter) {$aAdd= $user->userDataToDataBase($activityAdd , 'activity');
				if($aAdd) $success =  responseMsg(array('You Add New Activity') , 'success');
				else $errorMsg['bad_response'] =  "Sorry Error Happen Please Try Again Latter!";}
			else
			{
				$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}

				$errorMsg = responseMsg($msg , 'basic');
				
			}

	}


	if(isset($_POST['delete_activity_id']))
	{
		$skillDataDelete = $clear->clearedData($_POST['delete_activity_id'],'int');
		if(!is_array($skillDataDelete)) 
		{
			$delete = $user->deleteUserData($_POST['delete_activity_id'] , 'activity');
			if($delete) $success = responseMsg(array('You Deleted Your Activity Data!') , 'success');
			else  $errorMsg = responseMsg(array('Sorry Error Happen Please Try Again Latter!') , 'error');

		//$deleteConfirm = responseMsg( array(' You Want To Delete This Skill ?'), 'delete');
	    }else
	    {
	    		$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}
				$errorMsg = responseMsg($msg , 'basic');	
			
	    } 
	}