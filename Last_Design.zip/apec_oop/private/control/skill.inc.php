<?php


	if(isset($_POST['skill']))
	{
			$skillUserData = array('cert'=>$_POST['certificte']);
			$user->setData($skillUserData , array('string'));
			$filter = $user->filterDataAsArray();
			$user->setId(intval($_SESSION['user_id'])); 
			if(!is_array($filter) && $filter) {$skillData = $user->userDataToDataBase($skillUserData , 'skill');
				if($skillData) $success =  responseMsg(array('You Add New Skill') , 'success');
				else $errorMsg['bad_response'] =  "Sorry Error Happen Please Try Again Latter!";}
			else
			{
				$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}

				$errorMsg = responseMsg($msg , 'basic');
				
			}

	}

	// Delete Skill Of User Section ..!

	if(isset($_POST['delete_skill_id']))
	{
		$skillDataDelete = $clear->clearedData($_POST['delete_skill_id'],'int');
		if(!is_array($skillDataDelete)) 
		{
			$delete = $user->deleteUserData($_POST['delete_skill_id'] , 'skill');
			if($delete) $success = responseMsg(array('You Deleted Your Skill Data!') , 'success');
			else  $errorMsg = responseMsg(array('Sorry Error Happen Please Try Again Latter!') , 'error');

		//$deleteConfirm = responseMsg( array(' You Want To Delete This Skill ?'), 'delete');
	    }else
	    {
	    		$msg = array();
				foreach ($filter as $key => $value) {
					$msg = $value;
				}
				$errorMsg = responseMsg($msg , 'basic');	
			
	    } 
	}