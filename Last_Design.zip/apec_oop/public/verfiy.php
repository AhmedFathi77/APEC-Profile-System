<?php
      require_once("../private/includes/config.php");
 try

   {


      		if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['active']))
				{
					$clearData = new ClearData();
					$cruud = new Crud();

					$activeCode = addslashes($_GET['active']);
					$activeUser = $cruud ->setTableName('activition')->selectData($db_instance , array('active',"\"$activeCode\""));
					if($activeUser)
					{
						
						$activeUser = $cruud->setTableName('users')->setColumnName(array('active'))->setData(array(1))->update($db_instance , array('email' , "\"$activeUser[0]\""));

						if($activeUser)
						{
							$delete = $cruud->setTableName('activition')->deleteData($db_instance , array('active' , "\"$activeCode\""));
							if(!$delete) {throw new Exception("Sorry Some Thing Wrong Please Try Again Latter");}
							header('Location: login.php');
							exit();
						}else
						{
							throw new Exception("Sorry Some Thing Wrong Please Try Again Latter");
							
						}
					}else
					{
							header('Location: login.php');
					        exit();
					}


				}else
				{
					header('Location: login.php');
					exit();
				}



    }
	catch(Exception $e)
	{
		echo $e->getMessage();
	}



