<?php
  try
  {
      require_once("../private/includes/config.php");
      require(BASE_URI  . "private/includes/protectforms.inc.php");
      require(BASE_URI  . "private/includes/getuserlocation.inc.php"); // When Browser Load ..  

      redirectInside('profile.php');

              // 1. Check If User Phone (Email) Is Found In DataBase..
              // 2. IF Not Add User With Non Active Statues ..
              // 3. Send Sms To User ..
              // 4. Redirect User To Verfiy .. With Session Of Active Code ..
              // 5. If User Code Right Active User Statues To 1 .. 
              // 6. Redirect User To Login Page ..
              // Instance Of Clear Data Class Need In Register.inc.html ..
              $clearData = new ClearData();
              $errorMsg = array();
      if($_SERVER['REQUEST_METHOD'] == "POST")
      {
            // 0. Validata And Santize Data ..
              // Create Instance Of Class Clear Data .. Inside The Post Request I Not Want It OutSide it ..
              // $twilio_number , $account_id , $auth_token , Client $client
              $fromMyForm = (isset($_SESSION['form_protect']) && checkVaildToken($_SESSION['form_protect'] , $_POST['form_token']) && notEndOftimeOfSession()) ? true : false; 
                          

              if($fromMyForm)
              {
                            $sms = new Sms($TwilioService['twilio_number']  , $client);
                             
                            $curdd = new Crud();
                            $registerUser = new Register($db_instance , $curdd , $clearData);
                            // $dirty ,  $type 

                            // You Can But This Info As Chain Example :- -> setFirstName-> setlastName->setcountry
                            $firstName = $registerUser->setFirstName($_POST['first_name']);
                            $lastName  = $registerUser->setlastName($_POST['last_name']);
                            $pwd = $registerUser->setPwd($_POST['password']);
                            $country = $registerUser->setcountry($_POST['country']);
                            $phone = $registerUser->setEmail($_POST['email']);
                            
                            $addUser = $registerUser->addUser($sms);
                            if($addUser && !is_array($addUser))
                            {   
                                require_once('views/header.inc.html');
                                require_once('views/thanks.inc.html');
                                exit();
                            }

              }
             
              
      }

     

    /*   $sms = new Sms($TwilioService['twilio_number']  , $client);
       $user = new Register($db_instance ,  $curdd ,  $clearData );
       $userAdd = $user->setFirstName('hazem')->setlastName('khaled')->setPwd('5553332Zoma')->setcountry('EGYPT')->setPhone("01125724372")->addUser($sms);
       var_dump( $userAdd);*/
       //Save Session With Code .. 
        
       //$_SESSION['active_code'] = $userAdd; 
       
  //  }else throw new Exception("Sorry About That Please Try Again Later");



     
      require_once('views/header.inc.html');
      require_once('views/register.inc.html');

  }catch(EXCEPTION $e){


      echo $e->getMessage();

  }
