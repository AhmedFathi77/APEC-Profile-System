<?php
		
try
{
	    require_once("../private/includes/config.php");

	    
	    redirectOutSide('login.php');
	    

	    // LogOut Function ..
	    // Section Two ..

	    if(isset($_GET['logout']) && strtolower($_GET['logout']) == 'ok') 
	    {
	    	
	    	$_SESSION = array();
	    	session_destroy();
	    	redirectOutSide('login.php');
	    	exit();    
	    }
	    $getIdFromUrl = false; // This Flag To Determine If There is Id In Url Or Not ..
	    $errorMsg = array();
	    $succssMsg = array();
	    $clear = new ClearData();
	    $crud2 = new Crud();
	    $user = new User($db_instance , $crud2 , $clear , $sp);

	    $user->setId(intval($_SESSION['user_id']));




	    // Insert  Or Update Information .. 
	    // Section One ..
	    if($_SERVER['REQUEST_METHOD'] == "POST")
	    {
	    	require(BASE_URI . 'private/control/education.inc.php');
	    	require(BASE_URI . 'private/control/skill.inc.php');
	    	require(BASE_URI . 'private/control/about.inc.php');
	    	require(BASE_URI . 'private/control/train.inc.php');
	    	require(BASE_URI . 'private/control/course.inc.php');
	    	require(BASE_URI . 'private/control/activity.inc.php');
	    }



	    // Get Id Of User From Url .. Section Three ..
	    if(isset($_GET['id']))
	    {
	    	  $getIdFromUrl = (!is_array($clear->clearedData($_GET['id'] , 'int'))) ?  true : false ;
	    	  if($getIdFromUrl)	 $uid = (int) $_GET['id'];
	    	  else throw new Exception(" 404 Page Not Found  "); //Protect Me From Error !
	    }else $uid = intval($_SESSION['user_id']);


	    // To Check If User Can Edit This Info .. 
	    $canEdit = $user->canEdit($uid);


	  	$userInfo = $user->getUserData($uid);

	  	// If User Not Found Or Not Found ..
	    if($userInfo) $pageTitle =  $userInfo->getUserName();
	    else throw new Exception(" 404 Page Not Found  "); //Protect Me From Error !

	    // Get User Data To Display In Style Files .. Section Five ..
	    // Stored Information .. For With With Specific Id .. education_user_data(int id)
	    $eduData = $sp->selectData($uid , 'education'); // Retrive Data Of Education Of Specific User !
	    $aboutData = $sp->selectData($uid , 'about'); // Retrive Data Of Education Of Specific User !
	    $trainningData = $sp->selectData($uid , 'trainning');
	    $activitiesData = $sp->selectData($uid , 'activity');
	    $coursesData = $sp->selectData($uid, 'course');
	    $skillData = $sp->selectData($uid , 'skill');


	    // Style Section .. Section Four .. 
	    require(BASE_URI . "public/views/header.profile.inc.html");
	   
	    
	     /*
	require(BASE_URI . "public/views/about.inc.html");
	    require(BASE_URI . "public/views/education.inc.html");
	    require(BASE_URI . "public/views/skill.inc.html");
	    require(BASE_URI . "public/views/trainning.inc.html");
	    require(BASE_URI . "public/views/courses.inc.html");
	    require(BASE_URI . "public/views/activity.inc.html");
	    	    require(BASE_URI . "public/views/sponser.inc.html");

	*/




}catch(EXCEPTION $e)
{
	var_dump($e);
	exit();
	$pageTitle= 'Error!';
	require("views/error.inc.html");
	echo responseMsg(array('Page Not Found Or Some Thing Happen Wrong If You Feel That SomeThing Worng Please Contact Us At ' .CONTACT_EMAIL) , 'error');
	require("views/footer.inc.html");
	exit();

}




