<?php
try
{
	  require_once("../private/includes/config.php");

	  redirectOutSide('login.php'); // Last Function  In Config.php ..

	  // Some Insatance Of Important Class That User Here !
	  $cr = new Crud();
	  $clear = new ClearData();

	  $user = new User($db_instance , $cr ,$clear , $sp); // Instance Of User To Retrive Some Infor About him/her ..
	  $user->setId(intval($_SESSION['user_id']));

	  $userInfo = $user->getUserData($user->getId());
	  if(intval($userInfo->getfirstLogin()))
	  {
	  	
	  	redirectInside('profile.php');
	  	exit();

	  }

	  $errorMsg = array();
	  if($_SERVER['REQUEST_METHOD'] == 'POST')
	  {
	  			  $dataOfUserIn = array('uni_n'=>$_POST['uni'] , 'faculty_n'=>$_POST['faculty'] , 'year_n'=>$_POST['year'] , 'department_n'=>$_POST['department'] , 'grade_n'=>$_POST['grade'] ,  'is_garduated_n'=>'0' , 'lives_in_n'=>$_POST['lives_in'] , 'bio_n'=>$_POST['breif']);	
	  			  //$stored = new StoredProcedure();

				  $user ->setData($dataOfUserIn, array_fill(1, 8, 'string'));


				   
				
				  $filterData = $user->filterDataAsArray();
			

					if($filterData && !is_array($filterData))
					{
						
						// Put Data Into DataBase ..
					    // Education Section Of Data ..

						$edu = array_slice($dataOfUserIn, 0 , 6); // Start From Zero And End At 5 .. Example 0 , 1 , 2 , 3 , 4 , 5 (6 Items ..)
						// About Section Of Data ..
						$about = array_slice($dataOfUserIn, 6 , 7);
						
						$e = $user->userDataToDataBase($edu , 'education');
						$ab = $user->userDataToDataBase($about, 'about');
						//session_regenerate_id(); // Protect From Session Hjacking .. 
						if($ab && $e) 
						{ 
							// Must Change First Login For This User To 1 ..
							$firstLoginDone = $cr->setTableName('users')->setColumnName(array('first_login'))->setData(array(1))->update($db_instance   , array('id' , $user->getId()));
							if(!$firstLoginDone) throw new Exception("Error Processing Request Please Try Again Latter or Contact Us " . CONTACT_EMAIL);
							redirectInside('profile.php');
							exit();
						}
						{
							throw new Exception("Error Processing Request Please Try Again Latter or Contact Us " . CONTACT_EMAIL);
						}
					}else 
					{
						$errorMsg = $filterData; // This Need At File in.inc.html ..
					}

				 



	  }


	 			require("views/in.inc.html");

    

  




}catch(EXCEPTION $e)
{
	echo $e->getMessage();

}
	