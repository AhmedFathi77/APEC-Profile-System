document.querySelector('button#test-1').onclick = function(){
	swal("Here's a message!");
};
document.querySelector('button#test-2').onclick = function(){
	swal("Good job!", "You clicked the button!", "success");
};
function deleteData(message){
	 swal({   
    title: "Are you sure?",   
    text: message,   
    type: "warning",   
    showCancelButton: true,   confirmButtonColor: "#DD6B55",   confirmButtonText: "Yes, delete it!" });
};
document.querySelector('button#test-4').onclick = function(){
	swal("Oops...", "Something went wrong!", "error");
};