<?php

try
{	

	  require_once("../private/includes/config.php");
      require(BASE_URI  . "private/includes/protectforms.inc.php");
      redirectInside('profile.php');
      $clearData = new ClearData();

      if($_SERVER['REQUEST_METHOD'] == 'POST')
      {
      	    $fromMyForm = (isset($_SESSION['form_protect']) && checkVaildToken($_SESSION['form_protect'] , $_POST['form_token']) && notEndOftimeOfSession()) ? true : false;
      	    if($fromMyForm)
      	    {
      	    	$cruud = new Crud();
      	    	$userLogin = new Login($db_instance,$cruud,$clearData);
      	    	$userData = $userLogin->setEmail($_POST['email'])->setPassword($_POST['password'])->checkUserLogin();
      	    	$userRight = ($userData && array_key_exists('user_id', 	$userData)) ? true : false ;

      	    	if($userRight)
      	    	{
      	    		$notfirstLogin = ($userData['first_login']) ? true : false;
      	    		session_regenerate_id();
      	    		$_SESSION['user_id'] = $userData['user_id'];
      	    		if($notfirstLogin)
      	    		{
      	    				header("Location: profile.php");
      	    				exit();

      	    		}else
      	    		{
      	    				header("Location: inside.php");
      	    				exit();


      	    		}
      	    	

      	    	}


      	    }


      }

	  require_once('views/header.inc.html');
      require_once('views/login.inc.html');

}catch(EXCEPTION $e)
{
	echo $e->getMessage();
}