$(document).ready(function(){
	$("#add_skill").click(function(){
		$("#Skills_table").fadeIn(1000);
	});
	$("#cancel_skill").click(function(){
		$("#Skills_table").fadeOut(1000);
	});


	$("#add_course").click(function(){
		$("#course_table").fadeIn(1000);
	});
	$("#cancel_course").click(function(){
		$("#course_table").fadeOut(1000);
	})

	$("#add_trainnig").click(function(){
		$("#trainnig_table").fadeIn(1000);
	});
	$("#cancel_trainnig").click(function(){
		$("#trainnig_table").fadeOut(1000);
	});

	$("#add_Activity").click(function(){
		$("#Activity_table").fadeIn(1000);
	});
	$("#cancel_Activity").click(function(){
		$("#Activity_table").fadeOut(1000);
	})
});

