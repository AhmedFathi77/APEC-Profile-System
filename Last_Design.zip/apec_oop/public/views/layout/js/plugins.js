$(function () {
    'use strict';
    $('.side-menu').height($(window).height());
});