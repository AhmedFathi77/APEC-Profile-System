/*$(function(){
    'use strict' ;
    
    $("html").niceScroll({
        cursorcolor: '#eee',
        cursorwidth: 1,
        cursorborder: '1px solid #22A7F0'
        });
    
    });
*/
$(document).ready(function(){


     $(".f1").click(function(){
  $(".a1").fadeIn(function(){    
  $(".a2").fadeOut(),
  $(".a3").fadeOut(),
  $(".a4").fadeOut();
  $(".a5").fadeOut();

  });
  });
    
    $(".f2").click(function(){
  $(".a2").fadeIn(function(){    
  $(".a1").fadeOut(),
  $(".a3").fadeOut(),
  $(".a4").fadeOut();
  $(".a5").fadeOut();

  });
  });
    
     $(".f3").click(function(){
  $(".a3").fadeIn(function(){    
  $(".a1").fadeOut(),
  $(".a2").fadeOut(),
  $(".a4").fadeOut();
  $(".a5").fadeOut();

  });
  });
    
     $(".f4").click(function(){
  $(".a4").fadeIn(function(){    
  $(".a1").fadeOut(),
  $(".a2").fadeOut(),
  $(".a3").fadeOut();
        $(".a5").fadeOut();


  });
  });
    
     $(".f5").click(function(){
  $(".a5").fadeIn(function(){    
  $(".a1").fadeOut(),
  $(".a2").fadeOut(),
  $(".a3").fadeOut();
  $(".a4").fadeOut();
      

  });
  });
    


  });


 function insRow(id) {
    var x = document.getElementById(id).insertRow(0);
    var y = x.insertCell(0);
    var z = x.insertCell(1);
     var m = x.insertCell(2);
    var n = x.insertCell(3);
   
y.innerHTML ="<td>Certficate</td>";   
z.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='Certificte'></td>";
m.innerHTML ="<td>From</td>";
n.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='From'></td>";
}
            
            function insRow2(id) {
    var x = document.getElementById(id).insertRow(2);
    var y = x.insertCell(0);
    var z = x.insertCell(1);
     var m = x.insertCell(2);
    var n = x.insertCell(3);
    var s = document.getElementById(id).insertRow(3);
   
y.innerHTML ="<td>Trainnig</td>";   
z.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='Trainnig'></td>";
m.innerHTML ="<td>Date</td>";
n.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='Date'></td>";
s.innerHTML="<tr><td colspan='1'>Description</td><td colspan='4'><textarea class='form-control' rows='4' id='comment' placeholder='Bio about yourself'></textarea></td><tr>";                
}
            function insRow3(id) {
    var x = document.getElementById(id).insertRow(0);
    var y = x.insertCell(0);
    var z = x.insertCell(1);
     var m = x.insertCell(2);
    var n = x.insertCell(3);
   
y.innerHTML ="<td>Activity</td>";   
z.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='Activity name'></td>";
m.innerHTML ="<td>Position</td>";
n.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='What Do you do in this activity?'></td>";
}
    
 function insRow5(id) {
    var x = document.getElementById(id).insertRow(0);
    var y = x.insertCell(0);
    var z = x.insertCell(1);
     
   
y.innerHTML ="<td>Skills</td>";   
z.innerHTML ="<td><input type='text'class='form-control'id='usr'placeholder='Skill'></td>";

}