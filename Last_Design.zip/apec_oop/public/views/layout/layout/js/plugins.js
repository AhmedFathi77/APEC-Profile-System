 function logInWithFacebook() {
    FB.login(function(response) {
      if (response.authResponse) {
        //alert('You are logged in & cookie set!');
        // Now you can redirect the user or do an AJAX request to
        // a PHP script that grabs the signed request from the cookie.
        var button_facebook = document.getElementById('fblog');
        button_facebook.innerHTML="<i class='fa fa-facebook'></i>Processing ..";
       var data = {
        login: 'facebook',
      };
  
       $.ajax({
            //url: 'http://localhost/jobs/includes/ajax/fblogin.ajax.php',
            url: 'http://api.apec-eg.com/includes/ajax/fblogin.ajax.php',

            type: 'POST',
            data: data,
            dataType: 'json',
            success: function(data){
              
              if(data[0][0] == 'redirect'){
                window.location.href = data[0][1];
              } else if(data[0][0] == 'alert'){
                alert(data[0][1]);
              } else {
                $('.help-block').slideUp(300);
                for(var i = 0; i < data.length; i++){
                    //document.getElementById("helpblock").innerHTML += data[i][1];		
                  $('[name="' + data[i][0] + '"]').html("<i class='fa fa-facebook'></i>"+data[i][1]+"..");
                  
                }
              }
            },
            error: function(data){
               console.log(data);
            }
            });
      } else {
        alert('User cancelled login or did not fully authorize.');
      }
    });
    return false;
  }
 
  window.fbAsyncInit = function() {
    FB.init({
      appId: '1574555042866017',
      cookie: true, // This is important, it's not enabled by default
      version: 'v2.5'
    });
  };

  (function(d, s, id){
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {return;}
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
  
  
$(function(){
    'use strict';
    
  

  
  
  $(document).ready(function (){

    $('[name=end]').click(function (e){
      e.preventDefault();
      $('.help-block').slideUp(300);
      var data = {
        end: 'done',
      };
  
      $.ajax({
      url: 'includes/ajax/end_first-edit.ajax.php',
      type: 'POST',
      data: data,
      dataType: 'json',
      success: function(data){
        if(data[0][0] == 'redirect'){
          window.location.href = data[0][1];
        } else if(data[0][0] == 'alert'){
          alert(data[0][1]);
        }
      },
      error: function(data){
         console.log(data);
      }
      });
    });
    
    
     $('[name=fblogin]').click(function (e){
      e.preventDefault();
      $('.help-block').slideUp(300);
     
        logInWithFacebook();
      
    });
  
  });
  /*registration next previous defult actions */
  $('.testibtn.btn').click(function(){
        if($(this).hasClass('next')){
           
            $('.client.active').fadeOut(300, function(){
            
               $(this).removeClass('active').next('.client').removeClass('hidden').addClass('active').fadeIn(300);
                ///checkClients();
            });
        } else{
            $('.client.active').fadeOut(300, function(){
               $(this).removeClass('active').prev('.client').removeClass('hidden').addClass('active').fadeIn(300);
              /// checkClients();
            });
            
        }
    });

     
});